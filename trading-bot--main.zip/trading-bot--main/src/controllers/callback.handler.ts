import TelegramBot from "node-telegram-bot-api";
import {
  contractInfoScreenHandler,
  refreshHandler,
} from "../screens/contract.info.screen";
import { GasFeeEnum } from "../services/user.trade.setting.service";
import {
  buyCustomAmountScreenHandler,
  buyHandler,
  buyPreviewHandler,
  sellCustomAmountScreenHandler,
  sellHandler,
  setSlippageScreenHandler,
} from "../screens/trade.screen";
import {
  limitOrderDashboardHandler,
  limitOrderSetPriceHandler,
} from "../screens/limit.order.screen";
import {
  dcaDashboardHandler,
  dcaSetAmountHandler,
} from "../screens/dca.screen";
import {
  sniperModeHandler,
} from "../screens/sniper.screen";
import {
  copyTradeDashboardHandler,
  copyTradeSetSourceWalletHandler,
  createCopyTradeHandler,
  copyTradeSetTPHandler,
  copyTradeSetSLHandler,
  copyTradeToggleBuySellHandler,
  pauseCopyTradeHandler,
  resumeCopyTradeHandler,
  stopCopyTradeHandler,
} from "../screens/copy.trade.screen";
import {
  cancelWithdrawHandler,
  transferFundScreenHandler,
  withdrawButtonHandler,
  withdrawCustomAmountScreenHandler,
  withdrawHandler,
} from "../screens/transfer.funds";
import {
  WelcomeScreenHandler,
  welcomeGuideHandler,
} from "../screens/welcome.screen";
import {
  autoBuyAmountScreenHandler,
  changeGasFeeHandler,
  changeJitoTipFeeHandler,
  generateNewWalletHandler,
  importPrivateKeyHandler,
  importSeed12Handler,
  importSeed24Handler,
  pnlCardHandler,
  presetBuyAmountScreenHandler,
  presetBuyBtnHandler,
  revealWalletPrivatekyHandler,
  setCustomAutoBuyAmountHandler,
  setCustomFeeScreenHandler,
  setCustomJitoFeeScreenHandler,
  settingScreenHandler,
  switchAutoBuyOptsHandler,
  switchBurnOptsHandler,
  switchWalletHandler,
  walletViewHandler,
} from "../screens/settings.screen";
import { positionScreenHandler } from "../screens/position.screen";
import { OpenReferralWindowHandler } from "../screens/referral.link.handler";
import { MsgLogService } from "../services/msglog.service";
import { CopyTradeService } from "../services/copy.trade.service";
import { closeReplyMarkup } from "../screens/common.screen";
import {
  openAlertBotDashboard,
  sendMsgForAlertScheduleHandler,
  updateSchedule,
} from "../screens/bot.dashboard";
import {
  backToReferralHomeScreenHandler,
  refreshPayoutHandler,
  sendPayoutAddressManageScreen,
  setSOLPayoutAddressHandler,
} from "../screens/payout.screen";

export const callbackQueryHandler = async (
  bot: TelegramBot,
  callbackQuery: TelegramBot.CallbackQuery
) => {
  console.log("Callback received:", callbackQuery.data);
  try {
    const { data: callbackData, message: callbackMessage } = callbackQuery;
    if (!callbackData || !callbackMessage) return;

    const data = JSON.parse(callbackData);
    const opts = {
      chat_id: callbackMessage.chat.id,
      message_id: callbackMessage.message_id,
    };
    if (data.command.includes("dismiss_message")) {
      bot.deleteMessage(opts.chat_id, opts.message_id);
      return;
    }

    if (data.command.includes("cancel_withdraw")) {
      await cancelWithdrawHandler(bot, callbackMessage);
      return;
    }

    if (data.command.includes("dummy_button")) {
      return;
    }

    // main trading dashboard shortcuts
    if (data.command === "trade_buy") {
      bot.sendMessage(callbackMessage.chat.id, "🟢 Buy selected. Please paste the contract address to begin a purchase.");
      return;
    }
    if (data.command === "trade_sell") {
      bot.sendMessage(callbackMessage.chat.id, "🔴 Sell selected. Please paste the contract address to begin a sale.");
      return;
    }
    if (data.command === "trade_dca") {
      bot.sendMessage(callbackMessage.chat.id, "📈 DCA mode: send a contract address to start dollar-cost averaging.");
      return;
    }
    if (data.command === "trade_copytrade") {
      bot.sendMessage(callbackMessage.chat.id, "🤝 CopyTrade: send a contract address to copy another trade.");
      return;
    }
    if (data.command === "trade_sniper") {
      bot.sendMessage(callbackMessage.chat.id, "🎯 Sniper mode: send a contract address to snipe.");
      return;
    }
    if (data.command === "trade_limit") {
      bot.sendMessage(callbackMessage.chat.id, "⌛ Limit Order: send a contract address to set a limit order.");
      return;
    }

    if (data.command === "trade_copytrade") {
      bot.sendMessage(callbackMessage.chat.id, "📈 CopyTrade: send a contract address to copy another trade.");
      return;
    }

    if (data.command.includes("position")) {
      // const replaceId = callbackMessage.message_id;
      await positionScreenHandler(bot, callbackMessage);
      return;
    }

    if (data.command.includes("burn_switch")) {
      await switchBurnOptsHandler(bot, callbackMessage);
      return;
    }

    if (data.command.includes("autobuy_switch")) {
      await switchAutoBuyOptsHandler(bot, callbackMessage);
      return;
    }

    if (data.command.includes("autobuy_amount")) {
      const replaceId = callbackMessage.message_id;
      await autoBuyAmountScreenHandler(bot, callbackMessage, replaceId);
      return;
    }

    if (data.command === "pos_ref") {
      const replaceId = callbackMessage.message_id;
      await positionScreenHandler(bot, callbackMessage, replaceId);
      return;
    }

    // click on mint symbol from position
    if (data.command.includes("SPS_")) {
      const mint = data.command.slice(4);
      await contractInfoScreenHandler(
        bot,
        callbackMessage,
        mint,
        "switch_buy",
        true
      );
      return;
    }

    if (data.command.includes("BS_")) {
      const mint = data.command.slice(3);
      await contractInfoScreenHandler(bot, callbackMessage, mint, "switch_buy");
      return;
    }

    if (data.command.includes("SS_")) {
      const mint = data.command.slice(3);
      await contractInfoScreenHandler(
        bot,
        callbackMessage,
        mint,
        "switch_sell"
      );
      return;
    }

    if (data.command.includes("transfer_funds")) {
      const replaceId = callbackMessage.message_id;
      await transferFundScreenHandler(bot, callbackMessage, replaceId);
      return;
    }

    if (data.command.includes("TF_")) {
      const mint = data.command.slice(3);
      await withdrawButtonHandler(bot, callbackMessage, mint);
      return;
    }

    if (data.command.includes("withdrawtoken_custom")) {
      await withdrawCustomAmountScreenHandler(bot, callbackMessage);
      return;
    }

    const withdrawstr = "withdraw_";
    if (data.command.includes(withdrawstr)) {
      const percent = data.command.slice(withdrawstr.length);
      await withdrawHandler(bot, callbackMessage, percent);
      return;
    }

    if (data.command.includes("settings")) {
      console.log("Settings");
      const replaceId = callbackMessage.message_id;
      await settingScreenHandler(bot, callbackMessage, replaceId);
    }

    if (data.command.includes("generate_wallet")) {
      await generateNewWalletHandler(bot, callbackMessage);
    }

    if (data.command === "import_private_key") {
      await importPrivateKeyHandler(bot, callbackMessage);
    }

    if (data.command === "import_seed_12") {
      await importSeed12Handler(bot, callbackMessage);
    }

    if (data.command === "import_seed_24") {
      await importSeed24Handler(bot, callbackMessage);
    }

    const pkstr = "revealpk_";
    if (data.command.includes(pkstr)) {
      const nonce = Number(data.command.slice(pkstr.length));
      await revealWalletPrivatekyHandler(bot, callbackMessage, nonce);
    }

    const usewalletstr = "usewallet_";
    if (data.command.includes(usewalletstr)) {
      const nonce = Number(data.command.slice(usewalletstr.length));
      await switchWalletHandler(bot, callbackMessage, nonce);
    }

    if (data.command.includes("back_home")) {
      const replaceId = callbackMessage.message_id;
      await welcomeGuideHandler(bot, callbackMessage, replaceId);
    }

    if (data.command === "switch_gas") {
      await changeGasFeeHandler(bot, callbackMessage, GasFeeEnum.LOW);
      return;
    }
    if (data.command === "custom_gas") {
      await setCustomFeeScreenHandler(bot, callbackMessage);
      return;
    }

    if (data.command === "switch_mev") {
      await changeJitoTipFeeHandler(bot, callbackMessage);
      return;
    }

    if (data.command === "custom_jitofee") {
      await setCustomJitoFeeScreenHandler(bot, callbackMessage);
      return;
    }

    const buyTokenStr = "buytoken_";
    if (data.command.includes(buyTokenStr)) {
      const buyAmount = Number(data.command.slice(buyTokenStr.length));
      await buyHandler(bot, callbackMessage, buyAmount);
      return;
    }

    if (data.command === "confirm_buy") {
      const { amount, mint, msg_id } = data;
      await buyHandler(bot, callbackMessage, amount, msg_id);
      return;
    }
    const sellTokenStr = "selltoken_";
    if (data.command.includes(sellTokenStr)) {
      const sellPercent = Number(data.command.slice(sellTokenStr.length));
      await sellHandler(bot, callbackMessage, sellPercent);
      return;
    }
    if (data.command.includes("buy_custom")) {
      await buyCustomAmountScreenHandler(bot, callbackMessage);
      return;
    }

    // limit order initiation via contract info
    if (data.command === "limit_order") {
      await limitOrderSetPriceHandler(bot, callbackMessage);
      return;
    }

    // DCA mode
    if (data.command === "dca_mode") {
      await dcaSetAmountHandler(bot, callbackMessage);
      return;
    }

    // Copy trade mode
    if (data.command === "copy_trade") {
      await copyTradeSetSourceWalletHandler(bot, callbackMessage);
      return;
    }

    // Sniper mode
    if (data.command === "sniper_mode") {
      await sniperModeHandler(bot, callbackMessage);
      return;
    }

    if (data.command === "dca_refresh") {
      await dcaDashboardHandler(bot, callbackMessage);
      return;
    }

    if (data.command === "refresh_pnl") {
      await pnlCardHandler(bot, callbackMessage);
      return;
    }

    if (data.command.includes("sell_custom")) {
      await sellCustomAmountScreenHandler(bot, callbackMessage);
      return;
    }
    if (data.command.includes("set_slippage")) {
      await setSlippageScreenHandler(bot, callbackMessage);
      return;
    }
    if (data.command.includes("preset_setting")) {
      await presetBuyBtnHandler(bot, callbackMessage);
      return;
    }
    if (data.command.includes("wallet_view")) {
      await walletViewHandler(bot, callbackMessage);
      return;
    }

    // refresh dashboards
    if (data.command === "limit_orders_refresh") {
      await limitOrderDashboardHandler(bot, callbackMessage);
      return;
    }
    if (data.command === "copytrade_refresh") {
      await copyTradeDashboardHandler(bot, callbackMessage);
      return;
    }

    if (data.command === "referral") {
      await OpenReferralWindowHandler(bot, callbackMessage);
    }
    // Open payout dashboard
    if (data.command === "payout_address") {
      await sendPayoutAddressManageScreen(
        bot,
        callbackMessage.chat,
        callbackMessage.message_id
      );
    }
    // Update SOL address
    if (data.command === "set_sol_address") {
      await setSOLPayoutAddressHandler(bot, callbackMessage.chat);
    } else if (data.command === "refresh_payout") {
      await refreshPayoutHandler(bot, callbackMessage);
    }
    // Alert Bot
    if (data.command === "alert_bot" || data.command === "refresh_alert_bot") {
      bot.deleteMessage(callbackMessage.chat.id, callbackMessage.message_id);
      await openAlertBotDashboard(bot, callbackMessage.chat);
    }
    // Schedule
    else if (data.command.includes("alert_schedule")) {
      await sendMsgForAlertScheduleHandler(bot, callbackMessage.chat);
    }
    // Back home
    else if (data.command === "back_from_ref") {
      await backToReferralHomeScreenHandler(
        bot,
        callbackMessage.chat,
        callbackMessage
      );
    } else if (data.command.includes("schedule_time_")) {
      const scheduleTime = data.command.slice(14);

      await updateSchedule(bot, callbackMessage.chat, scheduleTime);
    }
    const presetBuyStr = "preset_buy_";
    if (data.command.includes(presetBuyStr)) {
      const preset_index = parseInt(data.command.slice(presetBuyStr.length));
      await presetBuyAmountScreenHandler(bot, callbackMessage, preset_index);
      return;
    }
    if (data.command === "refresh") {
      await refreshHandler(bot, callbackMessage);
      return;
    }

    if (data.command === "pnl_card") {
      await pnlCardHandler(bot, callbackMessage);
      return;
    }

    // Copy trade mode selection
    if (data.command && data.command.startsWith("copytrade_mode_")) {
      const mode = data.command.split("copytrade_mode_")[1];
      const source = data.source;
      if (mode === "mirror" || mode === "full") {
        // mirror and full behave the same - full implies both buys/sells
        await createCopyTradeHandler(bot, callbackMessage, {
          sourceWallet: source,
          mode: "mirror",
          fullCopy: mode === "full",
        });
      } else if (mode === "scalable") {
        // ask for scale factor
        const text = `💚 <b>Scale Factor</b> 💚\n\n<i>Enter percentage of the source trades to copy (e.g. 50 for 50%).</i>`;
        const sent = await bot.sendMessage(callbackMessage.chat.id, text, {
          parse_mode: "HTML",
          reply_markup: { force_reply: true },
        });
        await MsgLogService.create({
          username: callbackMessage.chat.username || "",
          mint: source,
          wallet_address: "",
          chat_id: callbackMessage.chat.id,
          msg_id: sent.message_id,
          parent_msgid: callbackMessage.message_id,
          extra_key: "copytrade_scale",
        });
      } else if (mode === "fixed") {
        const text = `💚 <b>Fixed Amount</b> 💚\n\n<i>Enter SOL amount to spend per copied trade.</i>`;
        const sent = await bot.sendMessage(callbackMessage.chat.id, text, {
          parse_mode: "HTML",
          reply_markup: { force_reply: true },
        });
        await MsgLogService.create({
          username: callbackMessage.chat.username || "",
          mint: source,
          wallet_address: "",
          chat_id: callbackMessage.chat.id,
          msg_id: sent.message_id,
          parent_msgid: callbackMessage.message_id,
          extra_key: "copytrade_fixed",
        });
      }
      return;
    }
    // Copy trade management menu
    if (data.command === "copytrade_manage") {
      const id = data.id;
      await copyTradeToggleBuySellHandler(bot, callbackMessage, id);
      return;
    }
    if (data.command === "copytrade_toggle_buys") {
      const id = data.id;
      await CopyTradeService.toggleCopyBuys(id);
      await bot.sendMessage(callbackMessage.chat.id, "✅ Copy buys setting updated.", closeReplyMarkup);
      return;
    }
    if (data.command === "copytrade_toggle_sells") {
      const id = data.id;
      await CopyTradeService.toggleCopySells(id);
      await bot.sendMessage(callbackMessage.chat.id, "✅ Copy sells setting updated.", closeReplyMarkup);
      return;
    }
    if (data.command === "copytrade_set_tp") {
      const id = data.id;
      await copyTradeSetTPHandler(bot, callbackMessage, id);
      return;
    }
    if (data.command === "copytrade_set_sl") {
      const id = data.id;
      await copyTradeSetSLHandler(bot, callbackMessage, id);
      return;
    }
    if (data.command === "copytrade_pause") {
      const id = data.id;
      await pauseCopyTradeHandler(bot, callbackMessage, id);
      return;
    }
    if (data.command === "copytrade_resume") {
      const id = data.id;
      await resumeCopyTradeHandler(bot, callbackMessage, id);
      return;
    }
    if (data.command === "copytrade_stop") {
      const id = data.id;
      await stopCopyTradeHandler(bot, callbackMessage, id);
      return;
    }
  } catch (e) {
    console.log(e);
  }
};
