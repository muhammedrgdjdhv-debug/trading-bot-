import { Commitment, Connection, PublicKey } from "@solana/web3.js";
import 'dotenv/config';

export const MONGODB_URL = process.env.MONGODB_URL || "mongodb://127.0.0.1:27017/coin-hunter";
export const TELEGRAM_BOT_API_TOKEN = process.env.TELEGRAM_BOT_API_TOKEN;
// alert bot uses a separate token by default, but fall back to the main bot token if
// none is provided.  This prevents 404 polling errors when only one token is set.
export const ALERT_BOT_TOKEN_SECRET =
  process.env.ALERT_BOT_API_TOKEN || TELEGRAM_BOT_API_TOKEN;

export const MAINNET_RPC = process.env.MAINNET_RPC || "https://api.mainnet-beta.solana.com";
export const RPC_WEBSOCKET_ENDPOINT = process.env.RPC_WEBSOCKET_ENDPOINT || "ws://api.mainnet-beta.solana.com";
export const PRIVATE_RPC_ENDPOINT = process.env.PRIVATE_RPC_ENDPOINT || "https://api.mainnet-beta.solana.com";
export const HELIUS_RPC = process.env.HELIUS_API_KEY ? `https://mainnet.helius-rpc.com/?api-key=${process.env.HELIUS_API_KEY}` : MAINNET_RPC;

export const COMMITMENT_LEVEL = 'finalized' as Commitment;
export const connection = new Connection(MAINNET_RPC, COMMITMENT_LEVEL);
export const private_connection = new Connection(PRIVATE_RPC_ENDPOINT, COMMITMENT_LEVEL);

const reserveWalletEnv = process.env.RESERVE_WALLET;
if (!reserveWalletEnv) {
  console.warn(
    "RESERVE_WALLET is not set. Fee/royalty transfers will be skipped or may fail. Set RESERVE_WALLET to a valid Solana public key in your .env."
  );
}

export const RESERVE_WALLET = reserveWalletEnv
  ? new PublicKey(reserveWalletEnv)
  : new PublicKey("11111111111111111111111111111111");

export const BIRDEYE_API_URL = "https://public-api.birdeye.so";
export const BIRDEYE_API_KEY = process.env.BIRDEYE_API || "";
export const JITO_UUID = process.env.JITO_UUID || "";
export const REQUEST_HEADER = {
  'accept': 'application/json',
  'x-chain': 'solana',
  'X-API-KEY': BIRDEYE_API_KEY,
};

export const REFERRAL_ACCOUNT = process.env.REFERRAL_ACCOUNT || "";

export const MIN = 60;
export const HOUR = 60 * MIN;
export const DAY = 24 * HOUR;
export const WK = 7 * DAY;

export const JUPITER_PROJECT = new PublicKey(
  "45ruCyfdRkWpRNGEqWzjCiXRHkZs8WXCLQ67Pnpye7Hp",
);

export const MAX_CHECK_JITO = 20

export const MAX_WALLET = 5;
export const COIN_HUNTER_VERSION = '| Beta Version';

export const COIN_HUNTER_API_ENDPOINT = process.env.COIN_HUNTER_API_ENDPOINT || "http://127.0.0.1:5001";
export const PNL_IMG_GENERATOR_API = process.env.PNL_IMG_GENERATOR_API || "http://127.0.0.1:3001";
export const JUPITER_BASE_PATH = process.env.JUPITER_BASE_PATH || "https://quote-api.jup.ag/v6";
export const JUPITER_API_KEY = process.env.JUPITER_API_KEY || "";

export const PNL_SHOW_THRESHOLD_USD = 0.00000005;
export const RAYDIUM_PASS_TIME = 5 * 60 * 60 * 1000; // 5 * 24  3days * 24h * 60mins * 60 seconds * 1000 millisecons
export const RAYDIUM_AMM_URL = 'https://api.raydium.io/v2/main/pairs'
export const RAYDIUM_CLMM_URL = 'https://api.raydium.io/v2/ammV3/ammPools'