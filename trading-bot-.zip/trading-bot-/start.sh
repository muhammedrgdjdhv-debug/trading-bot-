#!/bin/bash
set -e

DATA_DIR="$HOME/workspace/data/db"
mkdir -p "$DATA_DIR"

if ! pgrep -x mongod > /dev/null; then
  echo "Starting MongoDB..."
  mongod --dbpath "$DATA_DIR" --fork --logpath "$DATA_DIR/mongod.log" --bind_ip 127.0.0.1 --port 27017
  sleep 2
  echo "MongoDB started"
else
  echo "MongoDB is already running"
fi

echo "Starting trading bot..."
exec npx ts-node --transpile-only serve.ts
