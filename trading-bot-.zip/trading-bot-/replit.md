# Coin Hunter Trading Bot

A Solana-focused Telegram trading bot with support for sniping, DCA (Dollar Cost Averaging), copy trading, limit orders, and integration with Raydium, Jupiter, Pump.fun, Jito, and Birdeye.

## Architecture

- **Runtime**: Node.js 20 with TypeScript (via ts-node)
- **Bot Framework**: node-telegram-bot-api (polling mode)
- **Database**: MongoDB (local instance via mongod, port 27017)
- **Cache**: In-memory cache (Redis optional, falls back automatically if unavailable)
- **Blockchain**: Solana mainnet via @solana/web3.js

## Project Structure

```
serve.ts           # Entry point — connects MongoDB then starts bot
src/
  main.ts          # Bot initialization, command handlers, polling setup
  config.ts        # Environment variable exports and Solana connections
  controllers/     # Message and callback query handlers
  models/          # Mongoose schemas (user, trade, position, DCA, etc.)
  services/        # Business logic (Jupiter, Jito, user service, etc.)
  screens/         # Bot UI screens (welcome, position, settings, etc.)
  cron/            # Scheduled jobs (limit orders, DCA, alerts, price updates)
  raydium/         # Raydium AMM integration
  pump/            # Pump.fun integration
start.sh           # Startup script: launches mongod then ts-node serve.ts
```

## Required Secrets

| Secret | Description |
|--------|-------------|
| `TELEGRAM_BOT_API_TOKEN` | Main bot token from @BotFather (required) |
| `ALERT_BOT_API_TOKEN` | Optional separate alert bot token (falls back to main token) |
| `WALLET_MASTER_KEY` | Encryption key for stored user private keys |
| `RESERVE_PRIVATE_KEY` | Base58 or JSON array private key for the reserve/fee wallet |

## Optional Environment Variables (set via Replit env vars)

| Variable | Default | Description |
|----------|---------|-------------|
| `MONGODB_URL` | `mongodb://127.0.0.1:27017/coin-hunter` | MongoDB connection string |
| `MAINNET_RPC` | Public Solana RPC | Solana mainnet RPC endpoint |
| `HELIUS_API_KEY` | (none) | Helius enhanced RPC API key |
| `JUPITER_BASE_PATH` | `https://quote-api.jup.ag/v6` | Jupiter Quote API |
| `JITO_UUID` | (none) | Jito bundle UUID for MEV protection |
| `RESERVE_WALLET` | System address | Solana public key for fee/reserve wallet |
| `ADMIN_IDS` | (none) | Comma-separated Telegram user IDs for admins |
| `BOT_USERNAME` | (none) | Bot username without @ |

## Running

The workflow `Start application` runs `bash start.sh` which:
1. Starts MongoDB on port 27017 (forks as background process)
2. Runs the bot via `npx ts-node serve.ts`

## Setup Notes

- This is a pure backend Telegram bot — there is no web frontend
- Redis is optional — the bot falls back to an in-memory cache automatically
- The `bigint: Failed to load bindings` warning at startup is harmless (pure JS fallback is used)
- TypeScript compiles cleanly with `npx tsc --noEmit`
- MongoDB is installed as a Nix system dependency and started via `start.sh`
- The bot will not start without `TELEGRAM_BOT_API_TOKEN` set in the environment
