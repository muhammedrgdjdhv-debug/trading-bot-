# Coin Hunter Trading Bot

## Overview
A Solana-based cryptocurrency trading bot that operates via Telegram. It supports trading on major Solana DEXs including Raydium (AMM/CLMM), Jupiter, and Pump.fun.

## Tech Stack
- **Language:** TypeScript
- **Runtime:** Node.js 20
- **Database:** MongoDB (local via mongod)
- **Cache:** In-memory cache (Redis replaced)
- **Bot Interface:** Telegram Bot API
- **Blockchain:** Solana (Web3.js, SPL Token)
- **DEX Integrations:** Jupiter, Raydium, Pump.fun

## Project Structure
```
serve.ts           - Entry point (starts MongoDB + bot)
src/
  main.ts          - Telegram bot initialization and handlers
  config.ts        - Environment variable configuration
  bot.opts.ts      - Bot menu/options
  controllers/     - Telegram message and callback handlers
  cron/            - Scheduled jobs (limit orders, DCA, alerts, price updates)
  models/          - Mongoose schemas (Users, Trades, Positions, etc.)
  pump/            - Pump.fun trading logic
  raydium/         - Raydium DEX integration
  screens/         - Telegram UI generation (menus, settings, PNL)
  services/        - Core business logic (Jupiter, MongoDB, memory cache)
  utils/           - Helper utilities
start.sh           - Startup script (launches MongoDB then the bot)
data/db/           - MongoDB data directory
```

## Running the Application
```bash
bash start.sh
```
This starts MongoDB locally (port 27017) and then launches the bot via `npx ts-node serve.ts`.

## Required Environment Variables / Secrets
The following **secrets** must be set for the bot to function:
- `TELEGRAM_BOT_API_TOKEN` - Primary bot token (from @BotFather)
- `WALLET_MASTER_KEY` - Encryption key for user wallet private keys
- `RESERVE_PRIVATE_KEY` - Private key for the reserve/fee wallet (base58 or JSON array)

Optional secrets:
- `ALERT_BOT_API_TOKEN` - Token for alert bot (falls back to primary if not set)

Non-sensitive env vars (pre-configured with defaults in Replit):
- `MONGODB_URL` - mongodb://127.0.0.1:27017/coin-hunter
- `MAINNET_RPC` - Solana mainnet RPC endpoint
- `PRIVATE_RPC_ENDPOINT` - Private RPC endpoint
- `RPC_WEBSOCKET_ENDPOINT` - WebSocket RPC endpoint
- `JUPITER_BASE_PATH` - Jupiter quote API URL
- `COIN_HUNTER_API_ENDPOINT` - Internal API endpoint
- `PNL_IMG_GENERATOR_API` - PNL image generator service URL

Optional non-sensitive vars:
- `HELIUS_API_KEY` - Helius API key for enhanced RPC
- `JITO_UUID` - JITO bundle UUID for MEV protection
- `REFERRAL_ACCOUNT` - Referral wallet public key
- `RESERVE_WALLET` - Public key for fee/reserve wallet
- `COIN_HUNTER_BOT_ID`, `GROWSOL_ALERT_BOT_ID`, `BridgeBotID` - Bot IDs
- `BOT_USERNAME` - Bot username (without @)
- `ADMIN_IDS` - Comma-separated admin Telegram user IDs

## Workflow
- **Start application** (console): `bash start.sh`
  - Starts MongoDB then runs the Telegram bot process

## Notes
- No web frontend — this is a pure backend Telegram bot
- Redis has been replaced with an in-memory cache (`src/services/memory.cache.ts`)
- MongoDB runs locally; use MongoDB Atlas for production by setting `MONGODB_URL`
- The bot requires a valid Telegram token to start
