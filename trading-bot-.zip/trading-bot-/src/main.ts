import TelegramBot from "node-telegram-bot-api";
import { PNL_IMG_GENERATOR_API, TELEGRAM_BOT_API_TOKEN } from "./config";
import { AlertBotID, BotMenu, FEE_INFO_TEXT } from "./bot.opts";
import { runLimitOrderSchedule } from "./cron/limit.order.cron";
import { runCopyTradeListener } from "./cron/copy.trade.cron";
import { runDCASchedule } from "./cron/dca.cron";
import { WelcomeScreenHandler } from "./screens/welcome.screen";
import { callbackQueryHandler } from "./controllers/callback.handler";
import { messageHandler } from "./controllers/message.handler";
import { positionScreenHandler } from "./screens/position.screen";
import { tradeHistoryScreenHandler } from "./screens/trade.history.screen";
import { UserService } from "./services/user.service";
import { runAlertBotForChannel, runAlertBotSchedule } from "./cron/alert.bot.cron";
import {
  newReferralChannelHandler,
  removeReferralChannelHandler,
} from "./services/alert.bot.module";
import { runSOLPriceUpdateSchedule } from "./cron/sol.price.cron";
import { settingScreenHandler } from "./screens/settings.screen";
import {
  ReferralChannelService,
  ReferralPlatform,
} from "./services/referral.channel.service";
import { ReferrerListService } from "./services/referrer.list.service";
import { runListener } from "./raydium";
import { wait } from "./utils/wait";
import { runOpenmarketCronSchedule } from "./cron/remove.openmarket.cron";

const token = TELEGRAM_BOT_API_TOKEN;

if (!token) {
  throw new Error(
    "TELEGRAM_BOT API_KEY is not defined in the environment variables"
  );
}

export interface ReferralIdenticalType {
  referrer: string;
  chatId: string;
  messageId: string;
  channelName: string;
}

const startTradeBot = () => {
  const bot = new TelegramBot(token, { polling: true });
  let _lastPollingConflict = 0;
  bot.on('polling_error', (err: any) => {
    try {
      if (err && err.code === 'ETELEGRAM' && typeof err.message === 'string' && err.message.includes('409')) {
        const now = Date.now();
        if (now - _lastPollingConflict > 60000) {
          console.error('polling_error (409): another getUpdates request is active; suppressing repeated logs for 60s');
          _lastPollingConflict = now;
        }
        return;
      }
    } catch (e) {}
    console.error('polling_error', err);
  });
  //
  runOpenmarketCronSchedule();
  // Listen Raydium POOL creation
  runListener();
  // bot menu (pass the main bot so we don't create a second polling client)
  runAlertBotSchedule(bot);
  // Later: runAlertBotForChannel();
  runAlertBotForChannel(bot);
  runSOLPriceUpdateSchedule();
  runLimitOrderSchedule(bot);
  runCopyTradeListener(bot);
  runDCASchedule(bot);
  bot.setMyCommands(BotMenu);

  // bot callback
  bot.on(
    "callback_query",
    async function onCallbackQuery(callbackQuery: TelegramBot.CallbackQuery) {
      callbackQueryHandler(bot, callbackQuery);
    }
  );

  // bot message
  bot.on("message", async (msg: TelegramBot.Message) => {
    messageHandler(bot, msg);
  });

  // bot commands
  bot.onText(/\/start/, async (msg: TelegramBot.Message) => {
    // Need to remove "/start" text
    bot.deleteMessage(msg.chat.id, msg.message_id);

    await WelcomeScreenHandler(bot, msg);

    // Extract token — supports both random codes and @username / username
    const token = UserService.extractUniqueCode(msg.text ?? "");
    if (token && token !== "") {
      const chat = msg.chat;
      if (chat.username) {
        // Don't overwrite an existing referral
        const data = await UserService.findLastOne({ username: chat.username });
        if (data && data.referral_code && data.referral_code !== "") return;

        // Resolve token: try direct code first, then fall back to username lookup
        const resolvedCode = await UserService.resolveReferralCode(token);

        // Don't let users refer themselves
        if (resolvedCode) {
          const referrer = await UserService.findOne({ referrer_code: resolvedCode });
          if (referrer && referrer.username === chat.username) return;

          await UserService.updateMany(
            { username: chat.username },
            {
              referral_code: resolvedCode,
              referral_date: new Date(),
            }
          );
          console.log(`User @${chat.username} referred via token "${token}" → code "${resolvedCode}"`);
        }
      }
    }
  });
  bot.onText(/\/position/, async (msg: TelegramBot.Message) => {
    await positionScreenHandler(bot, msg);
  });

  bot.onText(/\/settings/, async (msg: TelegramBot.Message) => {
    await settingScreenHandler(bot, msg);
  });

  bot.onText(/\/fee_info/, async (msg: TelegramBot.Message) => {
    try {
      await bot.sendMessage(msg.chat.id, FEE_INFO_TEXT, {
        parse_mode: "HTML",
        disable_web_page_preview: true,
      });
    } catch (e) {
      console.error("fee_info command error:", e);
    }
  });

  bot.onText(/\/trade_history/, async (msg: TelegramBot.Message) => {
    await tradeHistoryScreenHandler(bot, msg);
  });

  bot.onText(/\/start/, async (msg: TelegramBot.Message) => {
    const { from, chat, text, message_id } = msg;
    console.log("AlertBotStart", `/start@${AlertBotID}`);
    if (text && text.includes(`/start@${AlertBotID}`)) {
      console.log("AlertBotStart Delete", Date.now());
      await wait(3000);
      console.log("AlertBotStart Delete", Date.now());

      try {
        bot.deleteMessage(chat.id, message_id);
      } catch (e) {}
      if (!from) return;
      if (!text.includes(" ")) return;
      const referrerInfo = await ReferrerListService.findLastOne({
        referrer: from.username,
        chatId: chat.id.toString(),
      });
      if (!referrerInfo) return;
      // for (const referrerInfo of referrerList) {
      const { referrer, chatId, channelName } = referrerInfo;
      // if (referrer === from.username && chat.id.toString() === chatId) {
      const parts = text.split(" ");
      if (parts.length < 1) {
        return;
      }
      if (parts[0] !== `/start@${AlertBotID}`) {
        return;
      }
      const botType = parts[1];
      if (botType === "tradebot") {
        const referralChannelService = new ReferralChannelService();
        await referralChannelService.addReferralChannel({
          creator: referrer,
          platform: ReferralPlatform.TradeBot,
          chat_id: chatId,
          channel_name: channelName,
        });
      } else if (botType === "bridgebot") {
        const referralChannelService = new ReferralChannelService();
        await referralChannelService.addReferralChannel({
          creator: referrer,
          platform: ReferralPlatform.BridgeBot,
          chat_id: chatId,
          channel_name: channelName,
        });
      }
      // }
      // }
    }
  });
  bot.on("new_chat_members", async (msg: TelegramBot.Message) => {
    console.log("new Members", msg);
    const data = await newReferralChannelHandler(msg);
    if (!data) return;

    try {
      console.log("New member created");
      await ReferrerListService.create(data);
      console.log("New member added ended");
    } catch (e) {}
  });
  bot.on("left_chat_member", async (msg: TelegramBot.Message) => {
    await removeReferralChannelHandler(msg);
  });
};

export default startTradeBot;
