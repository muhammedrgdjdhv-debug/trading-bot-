export const BotMenu = [
  { command: 'start', description: 'Welcome' },
  { command: 'position', description: 'Positions' },
  { command: 'settings', description: 'Settings & Tools' },
  { command: 'fee_info', description: 'Fee Structure' },
];

export const BUY_XSOL_TEXT = `🌳Buy X SOL\n\n<i>💲 Enter SOL Value in format "0.05"</i>`;
export const PRESET_BUY_TEXT = `🌳Preset Buy SOL Button \n\n<i>💲 Enter SOL Value in format "0.0X"</i>`;
export const AUTO_BUY_TEXT = `🌳Auto Buy SOL Button \n\n<i>💲 Enter SOL Value in format "0.0X"</i>`;
export const SELL_XPRO_TEXT = `🌳Sell X %\n\n<i>💲 Enter X Value in format "25.5"</i>`;
export const WITHDRAW_XTOKEN_TEXT = `🌳Withdraw X token\n\n<i>💲 Enter X Value in format "25.5"</i>`;
export const SET_SLIPPAGE_TEXT = `🌳Slippage X %\n\n<i>💲 Enter X Value in format "2.5"</i>`;
export let TradeBotID: string | undefined = process.env.COIN_HUNTER_BOT_ID;
export const setTradeBotID = (username: string) => { TradeBotID = username; };
export const WELCOME_REFERRAL = 'https://imgtr.ee/images/2024/04/22/24635465dd390956e0fb39857a66bab5.png';
export const ALERT_GT_IMAGE = 'https://imgtr.ee/images/2024/04/22/a84bf0785b7eef4a64cde8c26b28686b.png';
export const ALERT_GB_IMAGE = 'https://imgtr.ee/images/2024/03/28/24ec15df80dad1223fcea15793278bbe.png';
export const AlertBotID = process.env.GROWSOL_ALERT_BOT_ID;
export const BridgeBotID = process.env.BridgeBotID;

export const INPUT_SOL_ADDRESS = 'Please send your SOL payout address in solana network.';
export const SET_GAS_FEE = `🌳 Custom GAS\n\n<i>💲 Enter SOL Value in format "0.001"</i>`;
export const SET_JITO_FEE = `🌳 Custom Fee Amount\n\n<i>💲 Enter SOL Value in format "0.001"</i>`;

export const FEE_INFO_TEXT = `
<b>💚 COIN HUNTER - FEE STRUCTURE 💚</b>

<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>1. TRADING FEES (1% per trade)</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
When you buy or sell tokens, a 1% trading fee is applied:
  • 0.75% goes to Coin Hunter reserves
  • 0.25% is burned (removed from circulation)

<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>2. PRIORITY FEES (Gas)</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
Prioritizes your transaction on Solana:
  🔴 <b>LOW:</b> ~0.00001 SOL (slow, for non-urgent trades)
  🟡 <b>MEDIUM:</b> ~0.0001 SOL (default, balanced)
  🟢 <b>HIGH:</b> ~0.001 SOL (fast, for trending tokens)
  ⚙️ <b>CUSTOM:</b> Set your own amount directly

<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>3. MEV PROTECTION (Jito Bundle + Tips)</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
Protects you from sandwich attacks & front-running:
  🛡️ <b>What it does:</b> Bundles your tx with others
  💰 <b>Default Tip:</b> 0.0001 SOL
  ⚙️ <b>Custom Tip:</b> Adjust for varying network congestion
  
  ✓ Enables fast execution
  ✓ Reduces price slippage
  ✓ Protects against MEV extractors

<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>4. SLIPPAGE CONTROL</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
Max % difference between expected & actual output:
  • Default: 2-5% (recommended)
  • Adjust higher for volatile tokens
  • Lower = safer, but may fail on volatile markets

<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>5. REFERRAL REWARDS</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
Earn SOL by referring friends:
  📤 Share your referral link
  💚 Get % commission on their trades
  📊 Track earnings in /position

<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>COST EXAMPLE</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
Buying 1 SOL token:
  Trade Amount: 1 SOL
  Trading Fee (1%): 0.01 SOL
  Priority Fee: 0.0001 SOL
  Jito Tip: 0.0001 SOL
  <b>TOTAL COST: ~1.0102 SOL</b>

<i>💡 Configure fees in /settings</i>
`;

export const WITHDRAW_TOKEN_AMT_TEXT = `<i>🌳 Enter your receive wallet address</i>`;
export enum CommandEnum {
  CLOSE = "dismiss_message",
  Dismiss = "dismiss_message",
  REFRESH = "refresh"
}
