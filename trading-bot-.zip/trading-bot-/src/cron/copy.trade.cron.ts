import cron from "node-cron";
import { connection } from "../config";
import { PublicKey } from "@solana/web3.js";
import TelegramBot from "node-telegram-bot-api";
import { CopyTradeService } from "../services/copy.trade.service";
import { buyHandler, sellHandler } from "../screens/trade.screen";
import { UserService } from "../services/user.service";

const EVERY_15_SECONDS = "*/15 * * * * *";

// memory of processed signatures per source wallet
const processedSigs: Record<string, Set<string>> = {};

// Detect transaction type more accurately
const isBuyTx = (tx: any): boolean => {
  try {
    const ins = tx.transaction.message.instructions;
    const jupiterTx = ins.some((i: any) => i.programId?.toString().startsWith("JUP"));
    const raydiumTx = ins.some((i: any) => i.programId?.toString().includes("675kPX"));
    return jupiterTx || raydiumTx;
  } catch {
    return true; // Default to buy
  }
};

export const runCopyTradeListener = (bot: TelegramBot) => {
  try {
    cron.schedule(EVERY_15_SECONDS, async () => {
      try {
        const activeTrades = await CopyTradeService.getAllActive();
        if (!activeTrades || activeTrades.length === 0) return;

        for (const trade of activeTrades) {
          try {
            const src = trade.source_wallet;
            if (!processedSigs[src]) processedSigs[src] = new Set();

            const sigs = await connection.getSignaturesForAddress(new PublicKey(src), { limit: 10 });
            for (const info of sigs) {
              if (processedSigs[src].has(info.signature)) continue;
              processedSigs[src].add(info.signature);

              const tx = await connection.getTransaction(info.signature, { commitment: "finalized" });
              if (!tx) continue;

              const isBuy = isBuyTx(tx);
              const copiers = await CopyTradeService.getBySourceWallet(src);
              if (!copiers || copiers.length === 0) continue;

              console.log(`🔄 [COPY TRADE] Detected ${isBuy ? "BUY" : "SELL"} from ${src.slice(0, 8)}... for ${copiers.length} copiers`);

              for (const copier of copiers) {
                try {
                  // Skip if not copying this direction
                  if (isBuy && !copier.copy_buys) {
                    console.log(`⏭️ Skipping BUY for @${copier.username} (copy_buys disabled)`);
                    continue;
                  }
                  if (!isBuy && !copier.copy_sells) {
                    console.log(`⏭️ Skipping SELL for @${copier.username} (copy_sells disabled)`);
                    continue;
                  }

                  const user = await UserService.findOne({ username: copier.username });
                  if (!user) continue;

                  // Calculate copy amount based on copy mode
                  let copyAmount = copier.fixed_amount;
                  if (copier.copy_mode === "mirror") {
                    // For mirror: try to use a default or estimate based on user wallet
                    copyAmount = 0.05; // Default fallback
                  } else if (copier.copy_mode === "scalable") {
                    // For scalable: apply scale factor to default amount
                    copyAmount = (0.05 * copier.scale_factor);
                  }

                  const chatId = (copier as any).chat_id || user.chat_id || 0;
                  const fakeMsg: any = {
                    chat: { id: chatId, username: copier.username },
                    text: copier.source_wallet,
                    message_id: 0,
                  };

                  if (isBuy) {
                    console.log(`💚 Copying BUY for @${copier.username}: ${copyAmount} SOL (mode: ${copier.copy_mode})`);
                    await buyHandler(bot, fakeMsg, copyAmount);
                    await CopyTradeService.updateStats(copier._id.toString(), true, 0);

                    await bot.sendMessage(
                      chatId,
                      `✅ <b>Copy Trade Executed (BUY)</b>\n\n🔗 Source: ${copier.source_wallet.slice(0, 8)}...\n💰 Amount: ${copyAmount} SOL\n📊 Mode: ${copier.copy_mode}\n⏰ Total buys copied: ${(copier.total_buys_copied || 0) + 1}`,
                      { parse_mode: "HTML" }
                    ).catch(() => {});
                  } else {
                    console.log(`💚 Copying SELL for @${copier.username}: ${copier.scale_factor * 100}%`);
                    await sellHandler(bot, fakeMsg, copier.scale_factor * 100);
                    await CopyTradeService.updateStats(copier._id.toString(), false, 0);

                    await bot.sendMessage(
                      chatId,
                      `✅ <b>Copy Trade Executed (SELL)</b>\n\n🔗 Source: ${copier.source_wallet.slice(0, 8)}...\n💹 Sold: ${copier.scale_factor * 100}%\n⏰ Total sells copied: ${(copier.total_sells_copied || 0) + 1}`,
                      { parse_mode: "HTML" }
                    ).catch(() => {});
                  }

                  // Check and execute stop-loss/take-profit
                  const triggered = await CopyTradeService.checkAlerts(copier._id.toString());
                  if (triggered) {
                    await bot.sendMessage(
                      chatId,
                      `🛑 <b>Copy Trade Stopped</b>\n\n⚠️ Stop-loss or take-profit triggered (TP: ${copier.take_profit_percent}%, SL: ${copier.stop_loss_percent}%)!`,
                      { parse_mode: "HTML" }
                    ).catch(() => {});
                  }
                } catch (e) {
                  console.error(`Error executing copy trade for ${copier.username}:`, e);
                  const user = await UserService.findOne({ username: copier.username });
                  if (user) {
                    const errorChatId = (copier as any).chat_id || user.chat_id || 0;
                    await bot.sendMessage(
                      errorChatId,
                      `❌ <b>Copy Trade Error</b>\n\n${e instanceof Error ? e.message : "Unknown error"}`,
                      { parse_mode: "HTML" }
                    ).catch(() => {});
                  }
                }
              }
            }
          } catch (e) {
            console.error(`Copy trade error for ${trade.source_wallet}:`, e);
          }
        }
      } catch (e) {
        console.error("copy trade listener error:", e);
      }
    }).start();
  } catch (e) {
    console.error("failed to start copy trade listener:", e);
  }
};