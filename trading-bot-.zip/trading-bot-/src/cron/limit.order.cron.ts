import cron from "node-cron";
import { LimitOrderService } from "../services/limit.order.service";
import { LimitOrderStatusEnum } from "../models/limit.order.model";
import { getPriceInSOL } from "../raydium/raydium.service";
import { buyHandler, sellHandler } from "../screens/trade.screen";
import { UserService } from "../services/user.service";
import TelegramBot from "node-telegram-bot-api";

const EVERY_10_SECONDS = "*/10 * * * * *";

export const runLimitOrderSchedule = (bot: TelegramBot) => {
  try {
    cron.schedule(EVERY_10_SECONDS, async () => {
      try {
        const orders = await LimitOrderService.getAllPending();
        if (!orders || orders.length === 0) return;

        for (const order of orders) {
          try {
            const currentPrice = await getPriceInSOL(order.mint);
            if (currentPrice === null || currentPrice === undefined) continue;

            let triggered = false;
            if (order.order_type === "buy" && currentPrice <= order.trigger_price) {
              triggered = true;
            }
            if (order.order_type === "sell" && currentPrice >= order.trigger_price) {
              triggered = true;
            }

            if (triggered) {
              try {
                const user = await UserService.findOne({ username: order.username! });
                if (!user) {
                  console.error(`Limit order ${order._id}: User ${order.username} not found`);
                  continue;
                }

                console.log(`🎯 [LIMIT ORDER] Triggered ${order.order_type.toUpperCase()} on ${order.mint.slice(0, 8)}... for @${order.username}`);

                // Create mock message for execution
                const mockMsg: any = {
                  chat: { id: user.chat_id || 0, username: order.username },
                  text: order.mint,
                  message_id: 0,
                };

                if (order.order_type === "buy") {
                  console.log(`💚 Executing limit BUY: ${order.amount} SOL at ${order.trigger_price} SOL`);
                  await buyHandler(bot, mockMsg, order.amount);
                } else {
                  console.log(`💚 Executing limit SELL: ${order.amount}% at ${order.trigger_price} SOL`);
                  await sellHandler(bot, mockMsg, order.amount);
                }

                // Update order status to TRIGGERED
                await LimitOrderService.updateStatus(
                  order._id.toString(),
                  LimitOrderStatusEnum.TRIGGERED,
                  currentPrice
                );

                // Send success notification
                await bot.sendMessage(
                  user.chat_id || 0,
                  `✅ <b>Limit Order Executed</b> ✅\n\n` +
                    `📈 Token: ${order.mint.slice(0, 8)}...\n` +
                    `📍 Type: ${order.order_type.toUpperCase()}\n` +
                    `🎯 Trigger: ${order.trigger_price.toFixed(6)} SOL\n` +
                    `💹 Executed: ${currentPrice.toFixed(6)} SOL\n` +
                    `${order.order_type === "buy" ? `💰 Amount: ${order.amount} SOL` : `📊 Sold: ${order.amount}%`}`,
                  { parse_mode: "HTML" }
                ).catch(() => {});
              } catch (e) {
                console.error(`Error executing limit order ${order._id}:`, e);
                const user = await UserService.findOne({ username: order.username! });
                if (user) {
                  await bot.sendMessage(
                    user.chat_id || 0,
                    `❌ <b>Limit Order Execution Failed</b>\n\n${e instanceof Error ? e.message : "Unknown error"}`,
                    { parse_mode: "HTML" }
                  ).catch(() => {});
                } else {
                  await LimitOrderService.updateStatus(
                    order._id.toString(),
                    LimitOrderStatusEnum.FAILED,
                    currentPrice
                  );
                }
              }
            }
          } catch (e) {
            console.error("Error processing limit order:", e);
          }
        }
      } catch (e) {
        console.error("Limit cron iteration error:", e);
      }
    }).start();
  } catch (error) {
    console.error("Error starting limit order schedule:", error);
  }
};