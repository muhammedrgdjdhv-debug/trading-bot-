import cron from "node-cron";
import { LimitOrderService } from "../services/limit.order.service";
import { LimitOrderStatusEnum } from "../models/limit.order.model";
import { getPriceInSOL } from "../raydium/raydium.service";
import { buyHandler, sellHandler } from "../screens/trade.screen";
import { UserService } from "../services/user.service";
import { MsgLogService } from "../services/msglog.service";
import TelegramBot from "node-telegram-bot-api";
import { TokenService } from "../services/token.metadata";

const EVERY_10_SECONDS = "*/10 * * * * *";

async function getMarketCapUSD(mint: string): Promise<number> {
  try {
    const overview = await TokenService.getTokenOverview(mint);
    if (overview && (overview as any).marketCap) return Number((overview as any).marketCap);
    if (overview && overview.price && (overview as any).supply) {
      return overview.price * Number((overview as any).supply);
    }
    const resp = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, {
      headers: { Accept: 'application/json' },
    });
    const data = await resp.json();
    if (data?.pairs?.length > 0) {
      return parseFloat(data.pairs[0]?.marketCap || '0');
    }
  } catch (e) {
    console.warn(`getMarketCapUSD failed for ${mint}:`, e);
  }
  return 0;
}

export const runLimitOrderSchedule = (bot: TelegramBot) => {
  try {
    cron.schedule(EVERY_10_SECONDS, async () => {
      try {
        const orders = await LimitOrderService.getAllPending();
        if (!orders || orders.length === 0) return;

        for (const order of orders) {
          try {
            const triggerPrice: number = (order as any).trigger_price ?? 0;
            const triggerMcap: number = (order as any).trigger_market_cap ?? 0;

            let triggered = false;
            let currentPrice: number | null = null;
            let currentMcap: number | null = null;

            if (triggerPrice > 0) {
              currentPrice = await getPriceInSOL(order.mint);
              if (currentPrice !== null && currentPrice !== undefined) {
                if (order.order_type === 'buy' && currentPrice <= triggerPrice) triggered = true;
                if (order.order_type === 'sell' && currentPrice >= triggerPrice) triggered = true;
              }
            }

            if (!triggered && triggerMcap > 0) {
              currentMcap = await getMarketCapUSD(order.mint);
              if (currentMcap > 0) {
                if (order.order_type === 'buy' && currentMcap <= triggerMcap) triggered = true;
                if (order.order_type === 'sell' && currentMcap >= triggerMcap) triggered = true;
              }
            }

            if (!triggered) continue;

            try {
              const user = await UserService.findOne({ username: order.username! });
              if (!user) {
                console.error(`Limit order ${order._id}: User ${order.username} not found`);
                continue;
              }

              console.log(
                `🎯 [LIMIT ORDER] Triggered ${order.order_type.toUpperCase()} on ` +
                  `${order.mint.slice(0, 8)}... for @${order.username} ` +
                  `(price=${currentPrice?.toFixed(8) ?? 'N/A'}, mcap=$${currentMcap?.toFixed(0) ?? 'N/A'})`
              );

              const fakeMsgId = Date.now();
              const chatId = user.chat_id || 0;
              await MsgLogService.create({
                username: order.username!,
                mint: order.mint,
                wallet_address: user.wallet_address,
                chat_id: chatId,
                msg_id: fakeMsgId,
                parent_msgid: fakeMsgId,
                sol_amount: 999,
              });

              const mockMsg: any = {
                chat: { id: chatId, username: order.username },
                text: order.mint,
                message_id: fakeMsgId,
              };

              if (order.order_type === 'buy') {
                await buyHandler(bot, mockMsg, order.amount, fakeMsgId);
              } else {
                await sellHandler(bot, mockMsg, order.amount, fakeMsgId);
              }

              await LimitOrderService.updateStatus(
                order._id.toString(),
                LimitOrderStatusEnum.TRIGGERED,
                currentPrice ?? undefined
              );

              const mcStr =
                currentMcap != null && currentMcap > 0
                  ? currentMcap >= 1_000_000
                    ? `$${(currentMcap / 1_000_000).toFixed(2)}M`
                    : currentMcap >= 1_000
                    ? `$${(currentMcap / 1_000).toFixed(1)}K`
                    : `$${currentMcap.toFixed(0)}`
                  : null;

              const triggerLines: string[] = [];
              if (triggerPrice > 0) triggerLines.push(`📌 Price trigger: ${triggerPrice.toFixed(8)} SOL`);
              if (triggerMcap > 0) {
                const tmc = triggerMcap >= 1_000_000
                  ? `$${(triggerMcap / 1_000_000).toFixed(2)}M`
                  : triggerMcap >= 1_000
                  ? `$${(triggerMcap / 1_000).toFixed(1)}K`
                  : `$${triggerMcap.toFixed(0)}`;
                triggerLines.push(`📊 MCap trigger: ${tmc}`);
              }

              await bot
                .sendMessage(
                  user.chat_id || 0,
                  `✅ <b>Limit Order Executed</b> ✅\n\n` +
                    `📈 Token: <code>${order.mint.slice(0, 8)}...${order.mint.slice(-4)}</code>\n` +
                    `📍 Type: ${order.order_type.toUpperCase()}\n` +
                    triggerLines.join('\n') + '\n' +
                    (currentPrice != null ? `💹 Executed price: ${currentPrice.toFixed(8)} SOL\n` : '') +
                    (mcStr ? `📊 Executed MCap: ${mcStr}\n` : '') +
                    `${order.order_type === 'buy' ? `💰 Amount: ${order.amount} SOL` : `📊 Sold: ${order.amount}%`}`,
                  { parse_mode: 'HTML' }
                )
                .catch(() => {});
            } catch (e) {
              console.error(`Error executing limit order ${order._id}:`, e);
              await LimitOrderService.updateStatus(
                order._id.toString(),
                LimitOrderStatusEnum.FAILED,
                currentPrice ?? undefined
              );
              const user = await UserService.findOne({ username: order.username! });
              if (user) {
                await bot
                  .sendMessage(
                    user.chat_id || 0,
                    `❌ <b>Limit Order Execution Failed</b>\n\n${e instanceof Error ? e.message : 'Unknown error'}`,
                    { parse_mode: 'HTML' }
                  )
                  .catch(() => {});
              }
            }
          } catch (e) {
            console.error('Error processing limit order:', e);
          }
        }
      } catch (e) {
        console.error('Limit cron iteration error:', e);
      }
    }).start();
  } catch (error) {
    console.error('Error starting limit order schedule:', error);
  }
};
