import { NATIVE_MINT } from "@solana/spl-token";
import cron from "node-cron";
import redisClient from "../services/memory.cache";

const EVERY_5_SECONDS = "*/5 * * * * *";

export const runSOLPriceUpdateSchedule = () => {
  try {
    cron.schedule(EVERY_5_SECONDS, () => { updateSolPrice(); }).start();
  } catch (error) {
    console.error(`Error starting SOL price schedule: ${error}`);
  }
};

const updateSolPrice = async () => {
  try {
    const key = `${NATIVE_MINT.toString()}_price`;
    const price = await fetchSolPrice();
    if (price && price > 0) {
      await redisClient.set(key, String(price));
    }
  } catch (e) {
    console.warn("SOL price cron failed:", e);
  }
};

export const fetchSolPrice = async (): Promise<number> => {
  // 1. Try Jupiter Ag price API (free, reliable, Solana-native)
  try {
    const resp = await fetch(
      "https://api.jup.ag/price/v2?ids=So11111111111111111111111111111111111111112",
      { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(4000) }
    );
    const data = await resp.json();
    const price = data?.data?.["So11111111111111111111111111111111111111112"]?.price;
    if (price && Number(price) > 0) return Number(price);
  } catch (e) {
    console.warn("Jupiter price API failed:", (e as Error).message);
  }

  // 2. Try CoinGecko public API (free, no key needed)
  try {
    const resp = await fetch(
      "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd",
      { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(5000) }
    );
    const data = await resp.json();
    const price = data?.solana?.usd;
    if (price && Number(price) > 0) return Number(price);
  } catch (e) {
    console.warn("CoinGecko price API failed:", (e as Error).message);
  }

  // 3. Fallback: Dexscreener — find SOL/USDC or SOL/USDT pairs where SOL is the base
  try {
    const WSOL = "So11111111111111111111111111111111111111112";
    const resp = await fetch(
      `https://api.dexscreener.com/latest/dex/tokens/${WSOL}`,
      { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(5000) }
    );
    const data = await resp.json();
    if (data?.pairs && data.pairs.length > 0) {
      // Find pairs where baseToken is WSOL (priceUsd = SOL price)
      const solBasePair = data.pairs.find(
        (p: any) =>
          p.baseToken?.address === WSOL &&
          p.priceUsd &&
          parseFloat(p.priceUsd) > 50
      );
      if (solBasePair) return parseFloat(solBasePair.priceUsd);
      // Fallback: any pair where priceUsd looks like a SOL price
      const anySol = data.pairs.find(
        (p: any) => p.priceUsd && parseFloat(p.priceUsd) > 50
      );
      if (anySol) return parseFloat(anySol.priceUsd);
    }
  } catch (e) {
    console.warn("Dexscreener SOL price fallback failed:", (e as Error).message);
  }

  console.warn("All SOL price sources failed");
  return 0;
};
