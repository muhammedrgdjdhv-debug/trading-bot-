import { NATIVE_MINT } from "@solana/spl-token";
import cron from "node-cron";
import redisClient from "../services/memory.cache";
const EVERY_1_MIN = "*/5 * * * * *";
export const runSOLPriceUpdateSchedule = () => {
  try {
    cron
      .schedule(EVERY_1_MIN, () => {
        updateSolPrice();
      })
      .start();
  } catch (error) {
    console.error(
      `Error running the Schedule Job for fetching the chat data: ${error}`
    );
  }
};

const updateSolPrice = async () => {
  try {
    const solmint = NATIVE_MINT.toString();
    const key = `${solmint}_price`;
    
    // Use Dexscreener API (free, unlimited requests, no rate limits)
    // WSOL token address on Solana
    const WSOL_ADDRESS = "So11111111111111111111111111111111111111112";
    const response = await fetch(
      `https://api.dexscreener.com/latest/dex/tokens/${WSOL_ADDRESS}`,
      { 
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        }
      }
    );
    
    const res = await response.json();
    
    // Dexscreener returns pairs array, get the price from the first pair
    let price = null;
    if (res?.pairs && res.pairs.length > 0) {
      // Find the most liquid pair (usually first one)
      const pair = res.pairs[0];
      price = pair?.priceUsd ? parseFloat(pair.priceUsd) : null;
    }
    
    if (price === null || price === undefined || isNaN(price)) {
      console.log("SOL price: unexpected API response from Dexscreener", { res });
      return;
    }
    
    // store as string for compatibility
    await redisClient.set(key, String(price));
  } catch (e) {
    console.log("🚀 ~ SOL price cron job ~ Failed", e);
  }
};
