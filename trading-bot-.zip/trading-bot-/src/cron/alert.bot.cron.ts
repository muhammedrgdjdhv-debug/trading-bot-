import TelegramBot from "node-telegram-bot-api";
import {
  alertbotModule,
  sendAlertForOurChannel,
} from "../services/alert.bot.module";
import cron from "node-cron";

const EVERY_1_MIN = "*/1 * * * *";

// If you pass a `bot` instance it will be used. Otherwise, the cron will
// only create its own polling bot when a dedicated `ALERT_BOT_API_TOKEN` is
// provided in the environment. This avoids creating a second polling client
// when the alert token is intentionally the same as the main bot token.
const getPollBot = (bot?: TelegramBot) => {
  if (bot) return bot;
  const explicitAlertToken = process.env.ALERT_BOT_API_TOKEN || "";
  if (!explicitAlertToken || explicitAlertToken.trim() === "") return null;
  return new TelegramBot(explicitAlertToken, { polling: true });
};

export const runAlertBotSchedule = (bot?: TelegramBot) => {
  try {
    const pollBot = getPollBot(bot);
    cron
      .schedule(EVERY_1_MIN, async () => {
        // prefer passed bot, otherwise use the polling bot (if created)
        if (bot) {
          await alertbotModule(bot);
        } else if (pollBot) {
          await alertbotModule(pollBot);
        }
      })
      .start();
  } catch (error) {
    console.error(
      `Error running the Schedule Job for fetching the chat data: ${error}`
    );
  }
};

const EVERY_10_MIN = "0 * * * *";
export const runAlertBotForChannel = (bot?: TelegramBot) => {
  try {
    const pollBot = getPollBot(bot);
    cron
      .schedule(EVERY_10_MIN, async () => {
        if (bot) {
          await sendAlertForOurChannel(bot);
        } else if (pollBot) {
          await sendAlertForOurChannel(pollBot);
        }
      })
      .start();
  } catch (error) {
    console.error(
      `Error running the Schedule Job for fetching the chat data: ${error}`
    );
  }
};
