import TelegramBot from "node-telegram-bot-api";
import { DCAService } from "../services/dca.service";
import { buyHandler } from "../screens/trade.screen";
import { UserService } from "../services/user.service";
import { MsgLogService } from "../services/msglog.service";
import cron from "node-cron";

const EVERY_1_MIN = "*/1 * * * *";

export const runDCASchedule = (bot: TelegramBot) => {
  try {
    cron
      .schedule(EVERY_1_MIN, async () => {
        try {
          const dueDCAs = await DCAService.getDueDCAs();
          if (!dueDCAs || dueDCAs.length === 0) return;

          for (const dca of dueDCAs) {
            try {
              const user = await UserService.findOne({ username: dca.username });
              if (!user) {
                console.error(`DCA ${dca._id}: User ${dca.username} not found`);
                continue;
              }

              // Check balance
              const msglog = await MsgLogService.findOne({
                username: dca.username,
                mint: dca.mint,
              });
              if (!msglog || !msglog.sol_amount || msglog.sol_amount < dca.amount_per_buy) {
                const userChatId = user.chat_id || (user as any).telegram_id || 0;
                await bot.sendMessage(
                  userChatId,
                  `❌ <b>DCA Execution Failed</b>\n\n⚠️ Insufficient SOL balance for DCA buy.\nRequired: ${dca.amount_per_buy} SOL\nAvailable: ${msglog?.sol_amount || 0} SOL`,
                  { parse_mode: "HTML" }
                );
                continue;
              }

              // Create a proper mock message for buyHandler
              const userChatId = user.chat_id || (user as any).telegram_id || 0;
              const mockMsg = {
                chat: { id: userChatId, username: dca.username },
                message_id: 0,
                text: dca.mint,
              } as TelegramBot.Message;

              console.log(`🤖 [DCA] Executing ${dca.amount_per_buy} SOL on ${dca.mint} for @${dca.username}`);

              // Execute buy with DCA amount
              await buyHandler(bot, mockMsg, dca.amount_per_buy);

              // Update DCA after successful execution
              await DCAService.updateAfterBuy(dca._id.toString());

              // Send success notification
              const buysLeft = dca.total_buys > 0 ? (dca.total_buys - (dca.buys_completed + 1)) : "∞";
              await bot.sendMessage(
                userChatId,
                `✅ <b>DCA Executed</b>\n\n💰 Amount: ${dca.amount_per_buy} SOL\n📈 Token: ${dca.mint.slice(0, 8)}...\n⏰ Buys: ${dca.buys_completed + 1}/${dca.total_buys > 0 ? dca.total_buys : "∞"}\n⏳ Next in ${dca.interval_minutes}m`,
                { parse_mode: "HTML" }
              ).catch((e) => console.error("Failed to send DCA notification:", e));
            } catch (error) {
              console.error(`Error executing DCA ${dca._id}:`, error);
              const user = await UserService.findOne({ username: dca.username });
              if (user) {
                const errorChatId = user.chat_id || (user as any).telegram_id || 0;
                await bot.sendMessage(
                  errorChatId,
                  `❌ <b>DCA Execution Error</b>\n\n${error instanceof Error ? error.message : String(error)}`,
                  { parse_mode: "HTML" }
                ).catch(() => {});
              }
            }
          }
        } catch (e) {
          console.error("DCA iteration error:", e);
        }
      })
      .start();
  } catch (error) {
    console.error(`Error running DCA schedule: ${error}`);
  }
};