import axios from "axios";

export async function getCoinData(mintStr: string) {
  try {
    const url = `https://frontend-api.pump.fun/coins/${mintStr}`;
    const response = await axios.get(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
        Accept: "application/json",
      },
      timeout: 10000,
      validateStatus: (status) => status === 200,
    });

    return response.data;
  } catch (error: any) {
    const status = error?.response?.status;
    if (status) {
      console.warn(`Pump API returned ${status} for ${mintStr}. Marking as unavailable.`);
    } else {
      console.warn(`Pump API lookup failed for ${mintStr}: ${error?.message || error}`);
    }
    return null;
  }
}
