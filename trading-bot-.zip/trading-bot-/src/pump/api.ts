import axios from "axios";

const PUMP_ENDPOINTS = [
  "https://frontend-api.pump.fun",
  "https://client-api-2-74b1891ee9f9.herokuapp.com",
];

const PUMP_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
  Accept: "application/json",
  "Accept-Language": "en-US,en;q=0.9",
  Origin: "https://pump.fun",
  Referer: "https://pump.fun/",
};

export async function getCoinData(mintStr: string) {
  for (const base of PUMP_ENDPOINTS) {
    try {
      const url = `${base}/coins/${mintStr}`;
      const response = await axios.get(url, {
        headers: PUMP_HEADERS,
        timeout: 10000,
        validateStatus: (status) => status === 200,
      });
      return response.data;
    } catch (error: any) {
      const status = error?.response?.status;
      if (status === 404) {
        console.warn(`Pump API: coin not found on ${base} for ${mintStr}.`);
        return null;
      }
      console.warn(
        `Pump API returned ${status ?? error?.message ?? error} for ${mintStr} at ${base}. Trying next endpoint...`
      );
    }
  }
  console.warn(`Failed to retrieve coin data for ${mintStr} from all endpoints.`);
  return null;
}
