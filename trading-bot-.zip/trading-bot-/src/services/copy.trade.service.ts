import CopyTradeSchema, { CopyTradeStatusEnum } from "../models/copy.trade.model";

export class CopyTradeService {
  // Create a new copy trade
  static async create(data: any) {
    try {
      const copyTrade = new CopyTradeSchema(data);
      await copyTrade.save();
      return copyTrade;
    } catch (e) {
      console.error("Error creating copy trade:", e);
      return null;
    }
  }

  // Find all active copy trades for a user
  static async getActiveByUser(username: string) {
    try {
      const trades = await CopyTradeSchema.find({
        username,
        status: CopyTradeStatusEnum.ACTIVE,
      }).sort({ creation_time: -1 });
      return trades;
    } catch (e) {
      console.error("Error getting active copy trades:", e);
      return [];
    }
  }
  // Get all active copy trades across users
  static async getAllActive() {
    try {
      const trades = await CopyTradeSchema.find({
        status: CopyTradeStatusEnum.ACTIVE,
      });
      return trades;
    } catch (e) {
      console.error("Error getting all active copy trades:", e);
      return [];
    }
  }

  // Check both stop-loss and take-profit
  static async checkAlerts(id: string) {
    try {
      const trade = await CopyTradeSchema.findById(id);
      if (!trade) return false;

      let triggered = false;
      if (trade.max_loss_sol > 0 && trade.total_pnl < -trade.max_loss_sol) {
        await this.stop(id);
        triggered = true;
      }
      if (!triggered && trade.take_profit_percent > 0 && trade.total_pnl_percent > trade.take_profit_percent) {
        await this.stop(id);
        triggered = true;
      }
      return triggered;
    } catch (e) {
      console.error("Error checking alerts:", e);
      return false;
    }
  }
  // Find copy trades by source wallet (to track all copiers of a wallet)
  static async getBySourceWallet(
    sourceWallet: string,
    status: string = CopyTradeStatusEnum.ACTIVE
  ) {
    try {
      const trades = await CopyTradeSchema.find({
        source_wallet: sourceWallet,
        status,
      });
      return trades;
    } catch (e) {
      console.error("Error getting copy trades by source:", e);
      return [];
    }
  }

  // Get copy trade by ID
  static async findOne(id: string) {
    try {
      const trade = await CopyTradeSchema.findById(id);
      return trade;
    } catch (e) {
      console.error("Error finding copy trade:", e);
      return null;
    }
  }

  // Update copy trade
  static async update(id: string, updateData: any) {
    try {
      const trade = await CopyTradeSchema.findByIdAndUpdate(id, updateData, {
        new: true,
      });
      return trade;
    } catch (e) {
      console.error("Error updating copy trade:", e);
      return null;
    }
  }

  // Pause copy trade
  static async pause(id: string) {
    try {
      const trade = await CopyTradeSchema.findByIdAndUpdate(
        id,
        { status: CopyTradeStatusEnum.PAUSED },
        { new: true }
      );
      return trade;
    } catch (e) {
      console.error("Error pausing copy trade:", e);
      return null;
    }
  }

  // Resume copy trade
  static async resume(id: string) {
    try {
      const trade = await CopyTradeSchema.findByIdAndUpdate(
        id,
        { status: CopyTradeStatusEnum.ACTIVE },
        { new: true }
      );
      return trade;
    } catch (e) {
      console.error("Error resuming copy trade:", e);
      return null;
    }
  }

  // Stop copy trade
  static async stop(id: string) {
    try {
      const trade = await CopyTradeSchema.findByIdAndUpdate(
        id,
        { status: CopyTradeStatusEnum.STOPPED },
        { new: true }
      );
      return trade;
    } catch (e) {
      console.error("Error stopping copy trade:", e);
      return null;
    }
  }

  // Delete copy trade
  static async delete(id: string) {
    try {
      await CopyTradeSchema.findByIdAndDelete(id);
      return true;
    } catch (e) {
      console.error("Error deleting copy trade:", e);
      return false;
    }
  }

  // Get copy trade history for a user
  static async getHistory(username: string, limit: number = 50) {
    try {
      const trades = await CopyTradeSchema.find({ username })
        .sort({ creation_time: -1 })
        .limit(limit);
      return trades;
    } catch (e) {
      console.error("Error getting copy trade history:", e);
      return [];
    }
  }

  // Update stats after a trade
  static async updateStats(
    id: string,
    isBuy: boolean,
    pnl: number,
    txSig?: string
  ) {
    try {
      const updateData: any = {
        total_copied_trades: { $inc: 1 },
        last_trade_at: new Date(),
        total_pnl: { $inc: pnl },
      };

      if (isBuy) {
        updateData.total_buys_copied = { $inc: 1 };
      } else {
        updateData.total_sells_copied = { $inc: 1 };
      }

      const trade = await CopyTradeSchema.findByIdAndUpdate(id, updateData, {
        new: true,
      });
      
      // Recalculate percentage PNL
      if (trade) {
        const totalSol = trade.copy_mode === "fixed" 
          ? trade.fixed_amount * trade.total_copied_trades
          : 1; // This needs to be calculated differently based on actual trades
        const pnlPercent = totalSol > 0 ? (trade.total_pnl / totalSol) * 100 : 0;
        
        await CopyTradeSchema.findByIdAndUpdate(id, {
          total_pnl_percent: pnlPercent,
        });
      }
      
      return trade;
    } catch (e) {
      console.error("Error updating copy trade stats:", e);
      return null;
    }
  }

  // Check if should auto-stop based on loss
  static async checkStopLoss(id: string) {
    try {
      const trade = await CopyTradeSchema.findById(id);
      if (!trade) return false;

      if (trade.max_loss_sol > 0 && trade.total_pnl < -trade.max_loss_sol) {
        await this.stop(id);
        return true; // Auto-stopped
      }
      return false;
    } catch (e) {
      console.error("Error checking stop loss:", e);
      return false;
    }
  }

  // Count active copy trades for a user
  static async countActiveByUser(username: string) {
    try {
      const count = await CopyTradeSchema.countDocuments({
        username,
        status: CopyTradeStatusEnum.ACTIVE,
      });
      return count;
    } catch (e) {
      console.error("Error counting active copy trades:", e);
      return 0;
    }
  }

  // Update take profit
  static async setTakeProfit(id: string, percent: number) {
    try {
      const trade = await CopyTradeSchema.findByIdAndUpdate(
        id,
        { take_profit_percent: percent },
        { new: true }
      );
      return trade;
    } catch (e) {
      console.error("Error setting take profit:", e);
      return null;
    }
  }

  // Update stop loss
  static async setStopLoss(id: string, percent: number) {
    try {
      const trade = await CopyTradeSchema.findByIdAndUpdate(
        id,
        { stop_loss_percent: percent },
        { new: true }
      );
      return trade;
    } catch (e) {
      console.error("Error setting stop loss:", e);
      return null;
    }
  }

  // Toggle copy buys
  static async toggleCopyBuys(id: string) {
    try {
      const trade = await CopyTradeSchema.findById(id);
      if (!trade) return null;

      trade.copy_buys = !trade.copy_buys;
      return await trade.save();
    } catch (e) {
      console.error("Error toggling copy buys:", e);
      return null;
    }
  }

  // Toggle copy sells
  static async toggleCopySells(id: string) {
    try {
      const trade = await CopyTradeSchema.findById(id);
      if (!trade) return null;

      trade.copy_sells = !trade.copy_sells;
      return await trade.save();
    } catch (e) {
      console.error("Error toggling copy sells:", e);
      return null;
    }
  }
}
