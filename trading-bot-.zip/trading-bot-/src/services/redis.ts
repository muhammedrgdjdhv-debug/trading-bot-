import memoryCache from './memory.cache';

// Legacy interfaces kept for backward compatibility
import { GasFeeEnum, JitoFeeEnum } from './user.trade.setting.service';
import { TokenOverviewDataType, TokenSecurityInfoDataType } from './birdeye.api.service';

/**
 * Optional Redis helper.
 * If REDIS_URI is set and `redis` package is installed, it will use real Redis.
 * Otherwise it falls back to in-memory cache.
 */

interface CacheClient {
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
  expire(key: string, seconds: number): Promise<void>;
  del(key: string): Promise<void>;
  flushAll?(): Promise<void>;
}

let cache: CacheClient = memoryCache;

const redisUri = process.env.REDIS_URI;
if (redisUri) {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { createClient } = require('redis');
    const client = createClient({ url: redisUri });

    client.on('error', (err: any) => {
      console.warn('Redis client error, falling back to in-memory cache:', err?.message || err);
      cache = memoryCache;
    });

    client.connect().catch((err: any) => {
      console.warn('Redis connect failed, falling back to in-memory cache:', err?.message || err);
      cache = memoryCache;
    });

    cache = {
      get: async (key: string) => {
        const val = await client.get(key);
        return val;
      },
      set: async (key: string, value: string) => {
        await client.set(key, value);
      },
      expire: async (key: string, seconds: number) => {
        await client.expire(key, seconds);
      },
      del: async (key: string) => {
        await client.del(key);
      },
      flushAll: async () => {
        await client.flushAll();
      },
    };
  } catch (err: any) {
    console.warn('Redis package is not installed or could not be loaded, using in-memory cache:', err?.message || err);
    cache = memoryCache;
  }
}

export default cache;

// [username_mint] => { chatId, slippage, slippagebps, gasSetting }
// [mint_price] => price           # every 10 seconds
// [mint_overview] => overview     # every 6 hour (MC)
// [mint_secureinfo] => secureinfo # 1day
// [wallet_tokenaccounts] => Array<mint, balance>
export interface ITradeSlippageSetting {
  chatId?: number;
  slippage: number;
  slippagebps: number;
  wallet?: string
}

export interface ITradeGasSetting {
  gas: GasFeeEnum;
  value?: number;
}

export interface ITradeJioFeeSetting {
  jitoOption: JitoFeeEnum;
  value?: number;
}

export interface IMintPrice {
  price: number
}

export interface IMintOverview {
  overview: TokenOverviewDataType;
}

export interface IMintSecureInfo {
  secureinfo: TokenSecurityInfoDataType;
}
