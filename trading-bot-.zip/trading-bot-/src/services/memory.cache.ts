/**
 * Simple in-memory cache to replace Redis
 * Stores data with optional TTL expiration
 */

interface CacheEntry {
  value: any;
  expiresAt?: number;
}

class MemoryCache {
  private store: Map<string, CacheEntry> = new Map();

  /**
   * Get a value from cache
   */
  async get(key: string): Promise<any> {
    const entry = this.store.get(key);
    if (!entry) return null;

    // Check if expired
    if (entry.expiresAt && entry.expiresAt < Date.now()) {
      this.store.delete(key);
      return null;
    }

    return entry.value;
  }

  /**
   * Set a value in cache
   */
  async set(key: string, value: any): Promise<void> {
    this.store.set(key, { value });
  }

  /**
   * Set expiration time (in seconds)
   */
  async expire(key: string, seconds: number): Promise<void> {
    const entry = this.store.get(key);
    if (entry) {
      entry.expiresAt = Date.now() + seconds * 1000;
    }
  }

  /**
   * Delete a key
   */
  async del(key: string): Promise<void> {
    this.store.delete(key);
  }

  /**
   * Clear all cache (useful for testing)
   */
  async flushAll(): Promise<void> {
    this.store.clear();
  }

  /**
   * Cleanup expired entries periodically
   */
  startCleanup(intervalSeconds: number = 60): void {
    setInterval(() => {
      const now = Date.now();
      const keysToDelete: string[] = [];
      this.store.forEach((entry, key) => {
        if (entry.expiresAt && entry.expiresAt < now) {
          keysToDelete.push(key);
        }
      });
      keysToDelete.forEach(key => this.store.delete(key));
    }, intervalSeconds * 1000);
  }
}

const memoryCache = new MemoryCache();

// Start cleanup every 60 seconds
memoryCache.startCleanup(60);

export default memoryCache;
