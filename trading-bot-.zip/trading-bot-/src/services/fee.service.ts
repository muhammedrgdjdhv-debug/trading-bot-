import {
  Keypair,
  PublicKey,
  SystemProgram,
  TransactionInstruction,
} from "@solana/web3.js";
import bs58 from "bs58";
import { get_referral_info, CASHBACK_PERCENT } from "./referral.service";
import { RESERVE_WALLET, RESERVE_PRIVATE_KEY, connection } from "../config";
import {
  TOKEN_2022_PROGRAM_ID,
  TOKEN_PROGRAM_ID,
  createBurnInstruction,
  getAssociatedTokenAddressSync,
} from "@solana/spl-token";
import { sendTransactionV0 } from "../utils/v0.transaction";

export class FeeService {
  /**
   * Builds fee transfer instructions to include in the user's swap transaction.
   *
   * Referred users (0.85% total fee):
   *   - 25% of fee → referrer wallet (on-chain, same tx)
   *   - 75% of fee → reserve wallet (on-chain, same tx)
   *   - 3% cashback from reserve sent AFTER trade via sendCashbackFromReserve()
   *
   * Regular users (0.9% total fee):
   *   - 100% of fee → reserve wallet
   */
  async getFeeInstructions(
    total_fee_in_sol: number,
    total_fee_in_token: number,
    username: string,
    pk: string,
    mint: string,
    isToken2022: boolean
  ) {
    try {
      let wallet: Keypair;
      const decodedKey = bs58.decode(pk);
      if (decodedKey.length === 32) {
        wallet = Keypair.fromSeed(decodedKey);
      } else if (decodedKey.length === 64) {
        wallet = Keypair.fromSecretKey(decodedKey);
      } else {
        throw new Error(`Invalid private key length: ${decodedKey.length} bytes`);
      }

      const ref_info = await get_referral_info(username);
      console.log("🚀 ~ ref_info:", ref_info);

      const instructions: TransactionInstruction[] = [];

      if (ref_info?.referral && ref_info.referral_address) {
        const referralWallet = new PublicKey(ref_info.referral_address);
        const referralFeePercent = ref_info.referral_option ?? 25;

        const referralFee = Math.floor((total_fee_in_sol * referralFeePercent) / 100);
        const reserveFee = total_fee_in_sol - referralFee;

        console.log(
          `Fee split — total: ${total_fee_in_sol} lamports | referrer (${referralFeePercent}%): ${referralFee} | reserve: ${reserveFee}`
        );

        if (reserveFee > 0) {
          instructions.push(
            SystemProgram.transfer({
              fromPubkey: wallet.publicKey,
              toPubkey: RESERVE_WALLET,
              lamports: reserveFee,
            })
          );
        }
        if (referralFee > 0) {
          instructions.push(
            SystemProgram.transfer({
              fromPubkey: wallet.publicKey,
              toPubkey: referralWallet,
              lamports: referralFee,
            })
          );
        }
      } else {
        if (total_fee_in_sol > 0) {
          instructions.push(
            SystemProgram.transfer({
              fromPubkey: wallet.publicKey,
              toPubkey: RESERVE_WALLET,
              lamports: total_fee_in_sol,
            })
          );
        }
      }

      if (total_fee_in_token > 0) {
        const ata = getAssociatedTokenAddressSync(
          new PublicKey(mint),
          wallet.publicKey,
          true,
          isToken2022 ? TOKEN_2022_PROGRAM_ID : TOKEN_PROGRAM_ID
        );
        instructions.push(
          createBurnInstruction(
            ata,
            new PublicKey(mint),
            wallet.publicKey,
            BigInt(total_fee_in_token),
            [],
            isToken2022 ? TOKEN_2022_PROGRAM_ID : TOKEN_PROGRAM_ID
          )
        );
      }

      return instructions;
    } catch (e) {
      console.log("- Fee handler has issue", e);
      return [];
    }
  }
}

/**
 * Sends a cashback payment from the reserve wallet to a referred user's wallet.
 * Cashback = CASHBACK_PERCENT (3%) of the total fee they paid.
 *
 * Requirements:
 *  - User must have joined via a referral link
 *  - RESERVE_PRIVATE_KEY must be set in environment
 *  - cashback amount must be > 0 lamports
 *
 * Called asynchronously after a successful trade (fire-and-forget, non-blocking).
 */
export const sendCashbackFromReserve = async (
  total_fee_in_sol: number,
  userWalletAddress: string,
  username: string
): Promise<void> => {
  try {
    if (!RESERVE_PRIVATE_KEY) {
      console.log("Cashback skipped: RESERVE_PRIVATE_KEY not configured");
      return;
    }

    const ref_info = await get_referral_info(username);
    if (!ref_info?.referral) return;

    const cashbackLamports = Math.floor((total_fee_in_sol * CASHBACK_PERCENT) / 100);
    if (cashbackLamports <= 0) return;

    const decodedKey = bs58.decode(RESERVE_PRIVATE_KEY);
    let reserveKeypair: Keypair;
    if (decodedKey.length === 32) {
      reserveKeypair = Keypair.fromSeed(decodedKey);
    } else if (decodedKey.length === 64) {
      reserveKeypair = Keypair.fromSecretKey(decodedKey);
    } else {
      console.warn(`Cashback skipped: invalid RESERVE_PRIVATE_KEY length (${decodedKey.length})`);
      return;
    }

    const userWallet = new PublicKey(userWalletAddress);
    const instruction = SystemProgram.transfer({
      fromPubkey: reserveKeypair.publicKey,
      toPubkey: userWallet,
      lamports: cashbackLamports,
    });

    const txid = await sendTransactionV0(connection, [instruction], [reserveKeypair]);
    if (txid) {
      const cashbackSol = (cashbackLamports / 1e9).toFixed(6);
      console.log(
        `✅ Cashback sent: ${cashbackSol} SOL → @${username} (${userWalletAddress.slice(0, 8)}...) | TX: ${txid}`
      );
    } else {
      console.warn(`Cashback TX for @${username} returned no txid`);
    }
  } catch (e) {
    console.log("sendCashbackFromReserve failed:", e);
  }
};
