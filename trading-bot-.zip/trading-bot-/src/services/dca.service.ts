import DCA, { DCAStatusEnum } from "../models/dca.model";

export class DCAService {
  // Create a new DCA plan
  static async createDCA(data: {
    username: string;
    wallet_address: string;
    mint: string;
    amount_per_buy: number;
    interval_minutes: number;
    total_buys?: number;
  }) {
    const next_buy_at = new Date(Date.now() + data.interval_minutes * 60 * 1000);
    const dca = new DCA({
      ...data,
      next_buy_at,
      status: DCAStatusEnum.ACTIVE,
    });
    return await dca.save();
  }

  // Get active DCA plans for user
  static async getActiveDCAs(username: string) {
    return await DCA.find({
      username,
      status: DCAStatusEnum.ACTIVE,
    }).sort({ created_at: -1 });
  }

  // Get DCA by ID
  static async getDCAById(id: string) {
    return await DCA.findById(id);
  }

  // Update DCA after buy
  static async updateAfterBuy(id: string) {
    const dca = await DCA.findById(id);
    if (!dca) return;

    dca.buys_completed += 1;
    dca.last_buy_at = new Date();

    if (dca.total_buys > 0 && dca.buys_completed >= dca.total_buys) {
      dca.status = DCAStatusEnum.COMPLETED;
    } else {
      dca.next_buy_at = new Date(Date.now() + dca.interval_minutes * 60 * 1000);
    }

    return await dca.save();
  }

  // Pause DCA
  static async pauseDCA(id: string) {
    return await DCA.findByIdAndUpdate(id, { status: DCAStatusEnum.PAUSED });
  }

  // Resume DCA
  static async resumeDCA(id: string) {
    const dca = await DCA.findById(id);
    if (!dca) return;

    dca.status = DCAStatusEnum.ACTIVE;
    dca.next_buy_at = new Date(Date.now() + dca.interval_minutes * 60 * 1000);
    return await dca.save();
  }

  // Delete DCA
  static async deleteDCA(id: string) {
    return await DCA.findByIdAndDelete(id);
  }

  // Get DCAs due for execution
  static async getDueDCAs() {
    return await DCA.find({
      status: DCAStatusEnum.ACTIVE,
      next_buy_at: { $lte: new Date() },
    });
  }
}