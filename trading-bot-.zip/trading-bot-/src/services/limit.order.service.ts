import LimitOrderSchema, { LimitOrderStatusEnum } from "../models/limit.order.model";

export class LimitOrderService {
  // Create a new limit order
  static async create(data: any) {
    try {
      const order = new LimitOrderSchema(data);
      await order.save();
      return order;
    } catch (e) {
      console.error("Error creating limit order:", e);
      return null;
    }
  }

  // Find all active limit orders for a user
  static async getActiveOrders(username: string) {
    try {
      const orders = await LimitOrderSchema.find({
        username,
        status: LimitOrderStatusEnum.PENDING,
      }).sort({ creation_time: -1 });
      return orders;
    } catch (e) {
      console.error("Error getting active orders:", e);
      return [];
    }
  }

  // Find limit orders by mint (to check if prices should trigger)
  static async getOrdersByMint(mint: string, status: string = LimitOrderStatusEnum.PENDING) {
    try {
      const orders = await LimitOrderSchema.find({
        mint,
        status,
      });
      return orders;
    } catch (e) {
      console.error("Error getting orders by mint:", e);
      return [];
    }
  }

  // Get all pending orders across all mints
  static async getAllPending() {
    try {
      const orders = await LimitOrderSchema.find({
        status: LimitOrderStatusEnum.PENDING,
      });
      return orders;
    } catch (e) {
      console.error("Error getting all pending orders:", e);
      return [];
    }
  }

  // Get order by ID
  static async findOne(id: string) {
    try {
      const order = await LimitOrderSchema.findById(id);
      return order;
    } catch (e) {
      console.error("Error finding order:", e);
      return null;
    }
  }

  // Update order status
  static async updateStatus(
    id: string,
    status: string,
    executedPrice?: number,
    txSignature?: string
  ) {
    try {
      const updateData: any = {
        status,
        executed_at: new Date(),
      };
      if (executedPrice) updateData.executed_price = executedPrice;
      if (txSignature) updateData.tx_signature = txSignature;

      const order = await LimitOrderSchema.findByIdAndUpdate(id, updateData, {
        new: true,
      });
      return order;
    } catch (e) {
      console.error("Error updating order:", e);
      return null;
    }
  }

  // Cancel order
  static async cancel(id: string) {
    try {
      const order = await LimitOrderSchema.findByIdAndUpdate(
        id,
        { status: LimitOrderStatusEnum.CANCELLED },
        { new: true }
      );
      return order;
    } catch (e) {
      console.error("Error cancelling order:", e);
      return null;
    }
  }

  // Delete order
  static async delete(id: string) {
    try {
      await LimitOrderSchema.findByIdAndDelete(id);
      return true;
    } catch (e) {
      console.error("Error deleting order:", e);
      return false;
    }
  }

  // Get order history for a user
  static async getOrderHistory(username: string, limit: number = 50) {
    try {
      const orders = await LimitOrderSchema.find({ username })
        .sort({ creation_time: -1 })
        .limit(limit);
      return orders;
    } catch (e) {
      console.error("Error getting order history:", e);
      return [];
    }
  }

  // Count active orders for a user
  static async countActiveOrders(username: string) {
    try {
      const count = await LimitOrderSchema.countDocuments({
        username,
        status: LimitOrderStatusEnum.PENDING,
      });
      return count;
    } catch (e) {
      console.error("Error counting active orders:", e);
      return 0;
    }
  }
}
