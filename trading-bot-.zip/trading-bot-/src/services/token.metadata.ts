import { ASSOCIATED_TOKEN_PROGRAM_ID, AccountLayout, ExtensionType, NATIVE_MINT, TOKEN_2022_PROGRAM_ID, TOKEN_PROGRAM_ID, getAssociatedTokenAddressSync, getExtensionData, getExtensionTypes, getMetadataPointerState, getMint } from "@solana/spl-token";
import { COMMITMENT_LEVEL, MAINNET_RPC, connection } from "../config";
import { Metaplex, Metadata } from "@metaplex-foundation/js";
import { Connection, GetProgramAccountsFilter, PublicKey } from "@solana/web3.js";
import redisClient from "./redis";
import { formatNumber, getPrice } from "../utils";
import { BirdEyeAPIService, TokenOverviewDataType, TokenSecurityInfoDataType } from "./birdeye.api.service";
import { min } from "bn.js";
export interface ITokenAccountInfo {
  mint: string,
  amount: number,
  name: string,
  symbol: string
}

export interface MintExtention {
  extension: string, // transferFeeConfig,
  state: {
      newerTransferFee: {
          epoch: number, // 580,
          maximumFee: number, //  2328306436538696000,
          transferFeeBasisPoints: number, // 800
      },
      olderTransferFee: {
          epoch: number, // 580,
          maximumFee: number, // 2328306436538696000,
          transferFeeBasisPoints: number, // 800
      },
      transferFeeConfigAuthority: string,
      withdrawWithheldAuthority: string,
      withheldAmount: number, // 284998271699445
  }
}

export interface MintParsedInfo {
  decimals: number,
  freezeAuthority: string | null,
  isInitialized: Boolean,
  mintAuthority: string | null,
  supply: string,
  extension?: MintExtention[],
}



export interface MintParsed {
  info: MintParsedInfo,
  type: string, // 'mint'
}

export interface MintData {
  program: string; // 'spl-token', 'spl-token-2022'
  parsed: MintParsed,
  space: number,
}

const knownMints = [
  {
    mint: "FPymkKgpg1sLFbVao4JMk4ip8xb8C8uKqfMdARMobHaw",
    tokenName: "CoinHunter",
    tokenSymbol: "$GRW",
  },
  {
    mint: "HKYX2jvwkdjbkbSdirAiQHqTCPQa3jD2DVRkAFHgFXXT",
    tokenName: "Print Protocol",
    tokenSymbol: "$PRINT",
  },

]

export const TokenService = {
  getMintInfo: async (mint: string) => {
    try {
      // Special case for SOL (native mint)
      if (mint === NATIVE_MINT.toString()) {
        const overview = {
          address: mint,
          name: "Solana",
          symbol: "SOL",
          decimals: 9,
          liquidity: 0,
          price: 0,
          history30mPrice: 0,
          priceChange30mPercent: 0,
          history1hPrice: 0,
          priceChange1hPercent: 0,
          history2hPrice: 0,
          priceChange2hPercent: 0,
          history4hPrice: 0,
          priceChange4hPercent: 0,
          history6hPrice: 0,
          priceChange6hPercent: 0,
          history8hPrice: 0,
          priceChange8hPercent: 0,
          history12hPrice: 0,
          priceChange12hPercent: 0,
          history24hPrice: 0,
          priceChange24hPercent: 0,
          uniqueWallet30m: 0,
          uniqueWalletHistory30m: 0,
          uniqueWallet30mChangePercent: 0,
          uniqueWallet1h: 0,
          uniqueWalletHistory1h: 0,
          uniqueWallet1hChangePercent: 0,
          uniqueWallet2h: 0,
          uniqueWalletHistory2h: 0,
          uniqueWallet2hChangePercent: 0,
          uniqueWallet4h: 0,
          uniqueWalletHistory4h: 0,
          uniqueWallet4hChangePercent: 0,
          uniqueWallet6h: 0,
          uniqueWalletHistory6h: 0,
          uniqueWallet6hChangePercent: 0,
          uniqueWallet8h: 0,
          uniqueWalletHistory8h: 0,
          uniqueWallet8hChangePercent: 0,
          uniqueWallet12h: 0,
          uniqueWalletHistory12h: 0,
          uniqueWallet12hChangePercent: 0,
          uniqueWallet24h: 0,
          uniqueWalletHistory24h: 0,
          uniqueWallet24hChangePercent: 0,
          numberMarkets: 0,
        } as TokenOverviewDataType;

        const secureinfo = {
          preMarketHolder: [],
        } as TokenSecurityInfoDataType;

        return {
          overview,
          secureinfo,
        };
      }

      let overview = await TokenService.getTokenOverview(mint);
      let secureinfo: TokenSecurityInfoDataType;

      if (overview) {
        secureinfo = await TokenService.getTokenSecurity(mint);
      } else {
        // fallback: BirdEye could not return info, build a minimal overview from on-chain data
        console.warn(`TokenService.getMintInfo: overview not found for ${mint}, using on-chain fallback`);

        // fetch simple metadata (name & symbol) and decimals
        const simple = await TokenService.fetchSimpleMetaData(new PublicKey(mint));
        let decimals = 9;
        try {
          const mintInfo = await getMint(connection, new PublicKey(mint));
          decimals = mintInfo.decimals;
        } catch {
          // ignore, default to 9
        }

        overview = {
          address: mint,
          name: simple.name,
          symbol: simple.symbol,
          decimals,
          // fill some numeric fields with 0 to satisfy callers
          liquidity: 0,
          price: 0,
          history30mPrice: 0,
          priceChange30mPercent: 0,
          history1hPrice: 0,
          priceChange1hPercent: 0,
          history2hPrice: 0,
          priceChange2hPercent: 0,
          history4hPrice: 0,
          priceChange4hPercent: 0,
          history6hPrice: 0,
          priceChange6hPercent: 0,
          history8hPrice: 0,
          priceChange8hPercent: 0,
          history12hPrice: 0,
          priceChange12hPercent: 0,
          history24hPrice: 0,
          priceChange24hPercent: 0,
          uniqueWallet30m: 0,
          uniqueWalletHistory30m: 0,
          uniqueWallet30mChangePercent: 0,
          uniqueWallet1h: 0,
          uniqueWalletHistory1h: 0,
          uniqueWallet1hChangePercent: 0,
          uniqueWallet2h: 0,
          uniqueWalletHistory2h: 0,
          uniqueWallet2hChangePercent: 0,
          uniqueWallet4h: 0,
          uniqueWalletHistory4h: 0,
          uniqueWallet4hChangePercent: 0,
          uniqueWallet6h: 0,
          uniqueWalletHistory6h: 0,
          uniqueWallet6hChangePercent: 0,
          uniqueWallet8h: 0,
          uniqueWalletHistory8h: 0,
          uniqueWallet8hChangePercent: 0,
          uniqueWallet12h: 0,
          uniqueWalletHistory12h: 0,
          uniqueWallet12hChangePercent: 0,
          uniqueWallet24h: 0,
          uniqueWalletHistory24h: 0,
          uniqueWallet24hChangePercent: 0,
          numberMarkets: 0,
        } as TokenOverviewDataType;

        // basic security info fallback
        secureinfo = {
          preMarketHolder: [],
        } as TokenSecurityInfoDataType;
      }

      const resdata = {
        overview,
        secureinfo,
      } as {
        overview: TokenOverviewDataType,
        secureinfo: TokenSecurityInfoDataType,
      };

      return resdata;
    } catch (e) {
      console.error("getMintInfo error", e);
      return null;
    }
  },
  getTokenSecurity: async (mint: string) => {
    const key = `${mint}_security`;
    const redisdata = await redisClient.get(key);
    if (redisdata) {
      return JSON.parse(redisdata);
    }

    // Use basic on-chain security info instead of BirdEye API
    try {
      const mintPubkey = new PublicKey(mint);
      const mintInfo = await getMint(connection, mintPubkey);

      const secureinfo = {
        owner: mintInfo.mintAuthority?.toString() || null,
        creator: null, // Not available from basic mint info
        preMarketHolder: [],
        tokenAddress: mint,
        supply: mintInfo.supply.toString(),
        decimals: mintInfo.decimals,
        isInitialized: mintInfo.isInitialized,
        freezeAuthority: mintInfo.freezeAuthority?.toString() || null,
      };

      await redisClient.set(key, JSON.stringify(secureinfo));
      await redisClient.expire(key, 30);
      return secureinfo;
    } catch (e) {
      console.warn(`getTokenSecurity failed for ${mint}, using minimal fallback: ${e instanceof Error ? e.message : String(e)}`);
      // Fallback with minimal info
      const secureinfo = {
        owner: null,
        creator: null,
        preMarketHolder: [],
        tokenAddress: mint,
        supply: "0",
        decimals: 9,
        isInitialized: false,
        freezeAuthority: null,
      };
      return secureinfo;
    }
  },
  getTokenOverview: async (mint: string) => {
    const key = `${mint}_overview`;
    const redisdata = await redisClient.get(key);
    if (redisdata) {
      return JSON.parse(redisdata);
    }

    // fetch from Dexscreener instead of BirdEye; BirdEye is deprecated
    try {
      const url = `https://api.dexscreener.com/latest/dex/tokens/${mint}`;
      const resp = await fetch(url, { method: 'GET', headers: { Accept: 'application/json' } });
      const data = await resp.json();
      if (!data || !data.pairs || data.pairs.length === 0) {
        return null;
      }
      const pair = data.pairs[0];
      const token = pair.token || {};
      const overview = {
        address: mint,
        decimals: token.decimals || 0,
        symbol: token.symbol || undefined,
        name: token.name || undefined,
        extensions: {},
        logoURI: token.logoURI || undefined,
        liquidity: pair.liquidity ? Number(pair.liquidity) : 0,
        price: pair.priceUsd ? Number(pair.priceUsd) : 0,
        history30mPrice: 0,
        priceChange30mPercent: 0,
        history1hPrice: 0,
        priceChange1hPercent: 0,
        history2hPrice: 0,
        priceChange2hPercent: 0,
        history4hPrice: 0,
        priceChange4hPercent: 0,
        history6hPrice: 0,
        priceChange6hPercent: 0,
        history8hPrice: 0,
        priceChange8hPercent: 0,
        history12hPrice: 0,
        priceChange12hPercent: 0,
        history24hPrice: 0,
        priceChange24hPercent: 0,
        uniqueWallet30m: 0,
        uniqueWalletHistory30m: 0,
        uniqueWallet30mChangePercent: 0,
        uniqueWallet1h: 0,
        uniqueWalletHistory1h: 0,
        uniqueWallet1hChangePercent: 0,
        uniqueWallet2h: 0,
        uniqueWalletHistory2h: 0,
        uniqueWallet2hChangePercent: 0,
        uniqueWallet4h: 0,
        uniqueWalletHistory4h: 0,
        uniqueWallet4hChangePercent: 0,
        uniqueWallet6h: 0,
        uniqueWalletHistory6h: 0,
        uniqueWallet6hChangePercent: 0,
        uniqueWallet8h: 0,
        uniqueWalletHistory8h: 0,
        uniqueWallet8hChangePercent: 0,
        uniqueWallet12h: 0,
        uniqueWalletHistory12h: 0,
        uniqueWallet12hChangePercent: 0,
        uniqueWallet24h: 0,
        uniqueWalletHistory24h: 0,
        uniqueWallet24hChangePercent: 0,
        numberMarkets: 0,
      } as unknown as TokenOverviewDataType;

      await redisClient.set(key, JSON.stringify(overview));
      await redisClient.expire(key, 10);
      return overview;
    } catch (e: any) {
      console.warn(
        `getTokenOverview failed for ${mint}: ${e?.message || e}. ` +
          "Falling back to on-chain metadata only."
      );
      return null;
    }
  },
  fetchSecurityInfo: async (mint: PublicKey) => {
    try {
      const key = `${mint}_security`;
      await redisClient.expire(key, 0);
      const data = await redisClient.get(key);
      if (data) return JSON.parse(data);

      let mintInfo: any;
      let token2022 = false;
      // spltoken and token2022
      try {
        mintInfo = await getMint(
          connection,
          mint
        );
      } catch (error) {
        token2022 = true;
        mintInfo = await getMint(
          connection,
          mint,
          COMMITMENT_LEVEL,
          TOKEN_2022_PROGRAM_ID
        )
      }
      const mintdata = {
        token2022,
        address: mintInfo.address.toString(),
        mintAuthority: mintInfo.mintAuthority,
        supply: mintInfo.supply.toString(),
        decimals: mintInfo.decimals,
        isInitialized: mintInfo.isInitialized,
        freezeAuthority: mintInfo.freezeAuthority,
      }
      await redisClient.set(key, JSON.stringify(mintdata));
      if (mintInfo.freezeAuthority || mintInfo.freezeAuthority) {
        await redisClient.expire(key, 60);
      } else {
        await redisClient.expire(key, 24 * 3600);
      }
      return mintInfo;
    } catch (error) {
      console.log(error);
      return null;
    }
  },
  fetchMetadataInfo: async (mint: PublicKey) => {
    try {
      const filteredMints = knownMints.filter((item) => item.mint === mint.toString());
      if (filteredMints && filteredMints.length > 0) {
        const filteredMint = filteredMints[0];
        return {
          tokenName: filteredMint.tokenName,
          tokenSymbol: filteredMint.tokenSymbol,
          website: "",
          twitter: "",
          telegram: ""
        }
      }
      const key = `${mint}_metadata`;
      const data = await redisClient.get(key);
      if (data) return JSON.parse(data);
      const metaplex = Metaplex.make(connection);

      const mintAddress = new PublicKey(mint);

      let tokenName: any;
      let tokenSymbol: any;
      let website: any;
      let twitter: any;
      let telegram: any;

      const metadataAccount = metaplex
        .nfts()
        .pdas()
        .metadata({ mint: mintAddress });

      const metadataAccountInfo = await connection.getAccountInfo(metadataAccount);

      if (metadataAccountInfo) {
        const token = await metaplex.nfts().findByMint({ mintAddress: mintAddress });
        tokenName = token.name;
        tokenSymbol = token.symbol;

        if (token.json && token.json.extensions) {
          website = (token.json.extensions as any).website ?? "";
          twitter = (token.json.extensions as any).twitter ?? "";
          telegram = (token.json.extensions as any).twitter ?? "";
        }
      }
      await redisClient.set(key, JSON.stringify({
        tokenName,
        tokenSymbol,
        website,
        twitter,
        telegram
      }))
      return {
        tokenName,
        tokenSymbol,
        website,
        twitter,
        telegram
      }
    } catch (e) {
      return {
        tokenName: "",
        tokenSymbol: "",
        website: "",
        twitter: "",
        telegram: ""
      }
    }
  },
  getSPLBalance: async (mint: string, owner: string, isToken2022: boolean, isLive: boolean = false) => {
    let tokenBalance = 0;
    try {
      const key = `${owner}${mint}_balance`;
      const data = await redisClient.get(key);
      if (data && !isLive) return Number(data);
      const ata = getAssociatedTokenAddressSync(
        new PublicKey(mint),
        new PublicKey(owner),
        true,
        isToken2022 ? TOKEN_2022_PROGRAM_ID : TOKEN_PROGRAM_ID,
        ASSOCIATED_TOKEN_PROGRAM_ID
      )

      const balance = await connection.getTokenAccountBalance(ata);
      if (balance.value.uiAmount) {
        tokenBalance = balance.value.uiAmount;
        await redisClient.set(key, tokenBalance.toString());
        await redisClient.expire(key, 10);
      }
    } catch (e) {
      tokenBalance = 0;
    }
    return tokenBalance;
  },
  fetchSimpleMetaData: async (mint: PublicKey) => {
    try {
      const metaPlex = new Metaplex(connection);
      const metadata = await metaPlex
        .nfts()
        .findByMint({ mintAddress: mint })
      const tokenName = metadata.name;
      const tokenSymbol = metadata.symbol;
      return {
        name: tokenName,
        symbol: tokenSymbol,
      };
    } catch (e) {
      return {
        name: "",
        symbol: "",
      };
    }
  },
  getMintMetadata: async (
    connection: Connection,
    mint: PublicKey
  ): Promise<MintData | undefined> => {
    try {
      const key = `raymintmeta_${mint}`;
      const res = await redisClient.get(key);
      if (res) {
        return JSON.parse(res) as MintData;
      }
      const mintdata = await connection.getParsedAccountInfo(mint);
      if (!mintdata || !mintdata.value) {
        return;
      }
  
      const data = mintdata.value.data as MintData;
      await redisClient.set(key, JSON.stringify(data));
      await redisClient.expire(key, 30);
      return data;
    } catch (e) {
      return undefined;
    }
  },
  getSOLBalance: async (owner: string, isLive: boolean = false) => {
    let solBalance = 0;
    try {
      const key = `${owner}_solbalance`;
      const data = await redisClient.get(key);
      if (data && !isLive) return Number(data);
      const sol = await connection.getBalance(new PublicKey(owner));

      if (sol) {
        solBalance = sol / 10 ** 9;
        await redisClient.set(key, solBalance.toString());
        await redisClient.expire(key, 10);
      }
    } catch (e) {
      solBalance = 0;
    }
    return solBalance;
  },
  getSOLPrice: async () => {
    return getPrice(NATIVE_MINT.toString());
  },
  getSPLPrice: async (mint: string) => {
    return getPrice(mint);
  },
  getTokenAccounts: async (wallet: string): Promise<Array<ITokenAccountInfo>> => {
    try {
      const key = `${wallet}_tokenaccounts`;
      const data = await redisClient.get(key);
      if (data) return JSON.parse(data);

      const results: Array<ITokenAccountInfo> = await getaccounts(wallet);

      await redisClient.set(key, JSON.stringify(results));
      await redisClient.expire(key, 30);
      return results;
    } catch (e) { return [] }
  },
}

const getaccounts = async (owner: string) => {
  const results: Array<ITokenAccountInfo> = [];
  try {
    const ownerPublicKey = new PublicKey(owner);
    const tokenAccounts = await connection.getTokenAccountsByOwner(ownerPublicKey, {
      programId: TOKEN_PROGRAM_ID,
    });

    for (const { account, pubkey } of tokenAccounts.value) {
      const accountInfo = AccountLayout.decode(account.data);
      const mint = accountInfo.mint.toString();

      // Get decimals from mint
      let decimals = 9; // default
      try {
        const mintInfo = await getMint(connection, new PublicKey(mint));
        decimals = mintInfo.decimals;
      } catch (e) {
        // Use default decimals if mint fetch fails
      }

      const amount = Number(accountInfo.amount) / Math.pow(10, decimals);

      if (amount > 0) { // Only include accounts with balance
        let tokenName = '';
        let tokenSymbol = '';

        try {
          const { name, symbol } = await TokenService.fetchSimpleMetaData(new PublicKey(mint));
          tokenName = name;
          tokenSymbol = symbol;

          if (!name && !symbol) {
            const res = await TokenService.getMintInfo(mint);
            tokenName = res?.overview.name as string || '';
            tokenSymbol = res?.overview.symbol as string || '';
          }
        } catch (e) {
          // Metadata fetch failed, continue with empty name/symbol
        }

        results.push({ mint, amount, name: tokenName, symbol: tokenSymbol });
      }
    }
  } catch (e) {
    console.error("Error fetching token accounts:", e);
  }

  return results;
}