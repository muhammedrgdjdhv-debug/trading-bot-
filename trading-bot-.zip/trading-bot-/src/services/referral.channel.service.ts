import { ReferralChannelSchema } from "../models/index";
import { UserService } from "./user.service";

export enum ReferralPlatform {
  TradeBot,
  BridgeBot
}

export class ReferralChannelService {
  async createReferralChannel(
    creator: string,
    referral_code: string
  ) {
    try {
      const existing = await ReferralChannelSchema.findOne({ creator, referral_code });
      if (existing) return existing;
      return await ReferralChannelSchema.create({ creator, referral_code, chat_id: "", channel_name: "" });
    } catch (e) {
      console.log("createReferralChannel error:", e);
      return null;
    }
  }

  async addReferralChannel(data: {
    creator: string;
    platform?: ReferralPlatform;
    chat_id: string;
    channel_name: string;
    referral_code?: string;
  }) {
    try {
      let referral_code = data.referral_code;
      if (!referral_code) {
        const user = await UserService.findOne({ username: data.creator });
        referral_code = user?.referrer_code ?? "";
      }
      if (!referral_code) {
        console.log("addReferralChannel: no referral_code for creator", data.creator);
        return null;
      }
      const existing = await ReferralChannelSchema.findOne({
        creator: data.creator,
        chat_id: data.chat_id,
      });
      if (existing) {
        existing.channel_name = data.channel_name;
        existing.referral_code = referral_code;
        await existing.save();
        return existing;
      }
      return await ReferralChannelSchema.create({
        creator: data.creator,
        chat_id: data.chat_id,
        channel_name: data.channel_name,
        referral_code,
      });
    } catch (e) {
      console.log("addReferralChannel error:", e);
      return null;
    }
  }

  async updateReferralChannel(data: {
    creator: string;
    chat_id?: string;
    channel_name?: string;
    referral_code?: string;
    platform?: ReferralPlatform;
    schedule?: string;
    [key: string]: any;
  }) {
    try {
      const update: any = {};
      if (data.channel_name !== undefined) update.channel_name = data.channel_name;
      if (data.referral_code !== undefined) update.referral_code = data.referral_code;
      const filter: any = { creator: data.creator };
      if (data.chat_id) filter.chat_id = data.chat_id;
      return await ReferralChannelSchema.findOneAndUpdate(
        filter,
        { $set: update },
        { new: true }
      );
    } catch (e) {
      console.log("updateReferralChannel error:", e);
      return null;
    }
  }

  async deleteReferralChannel(data: {
    creator: string;
    chat_id: string;
    channel_name?: string;
  }) {
    try {
      return await ReferralChannelSchema.findOneAndDelete({
        creator: data.creator,
        chat_id: data.chat_id,
      });
    } catch (e) {
      console.log("deleteReferralChannel error:", e);
      return null;
    }
  }

  async getAllReferralChannels() {
    try {
      return await ReferralChannelSchema.find({});
    } catch (e) {
      console.log("getAllReferralChannels error:", e);
      return null;
    }
  }

  async deleteChannelById(creator: string, chatId: string) {
    try {
      return await ReferralChannelSchema.findOneAndDelete({ creator, chat_id: chatId });
    } catch (e) {
      console.log("deleteChannelById error:", e);
      return null;
    }
  }
}
