/** @format */

import mongoose from "mongoose";
const Schema = mongoose.Schema;

// Copy Trade Status Enum
export const CopyTradeStatusEnum = {
  ACTIVE: "active",
  PAUSED: "paused",
  STOPPED: "stopped",
};

// Copy Trade Schema - for users to copy trades from other wallets
const CopyTrade = new Schema(
  {
    username: {
      type: String,
      required: true,
      index: true,
    },
    wallet_address: {
      type: String,
      required: true,
    },
    // Wallet address to copy trades from
    source_wallet: {
      type: String,
      required: true,
      index: true,
    },
    source_wallet_label: {
      type: String,
      default: "",
    },
    // Copy Mode
    copy_mode: {
      type: String,
      enum: ["mirror", "scalable", "fixed"],
      default: "mirror",
      // mirror: copy exact amount
      // scalable: scale by percentage (e.g., user puts in 0.5x scale)
      // fixed: fixed SOL amount per trade (regardless of source)
    },
    // Scale factor (only for scalable mode)
    scale_factor: {
      type: Number,
      default: 1.0, // 1.0 = 100%, 0.5 = 50%, 2.0 = 200%
    },
    // Fixed amount (only for fixed mode)
    fixed_amount: {
      type: Number,
      default: 0,
    },
    // whether this was created using "full copy" option
    full_copy: {
      type: Boolean,
      default: false,
    },
    // Copy settings
    copy_buys: {
      type: Boolean,
      default: true,
    },
    copy_sells: {
      type: Boolean,
      default: true,
    },
    // Stop loss in percentage
    stop_loss_percent: {
      type: Number,
      default: 0, // 0 = disabled
    },
    // Take profit in percentage
    take_profit_percent: {
      type: Number,
      default: 0, // 0 = disabled
    },
    // Auto-stop if loss exceeds this amount in SOL
    max_loss_sol: {
      type: Number,
      default: 0, // 0 = unlimited
    },
    // Status
    status: {
      type: String,
      enum: Object.values(CopyTradeStatusEnum),
      default: CopyTradeStatusEnum.ACTIVE,
    },
    // Stats
    total_copied_trades: {
      type: Number,
      default: 0,
    },
    total_buys_copied: {
      type: Number,
      default: 0,
    },
    total_sells_copied: {
      type: Number,
      default: 0,
    },
    total_pnl: {
      type: Number,
      default: 0,
    },
    total_pnl_percent: {
      type: Number,
      default: 0,
    },
    // Last trade timestamp
    last_trade_at: {
      type: Date,
      default: null,
    },
    creation_time: {
      type: Number,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// Index for active copy trades lookup
CopyTrade.index({ username: 1, status: 1 });
CopyTrade.index({ source_wallet: 1, status: 1 });

export default mongoose.model("copy_trade", CopyTrade);
