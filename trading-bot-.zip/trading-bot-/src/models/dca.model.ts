/** @format */

import mongoose from "mongoose";
const Schema = mongoose.Schema;

// DCA Status Enum
export const DCAStatusEnum = {
  ACTIVE: "active",
  PAUSED: "paused",
  COMPLETED: "completed",
  FAILED: "failed",
};

// DCA Schema - for dollar-cost averaging
const DCA = new Schema(
  {
    username: {
      type: String,
      required: true,
      index: true,
    },
    wallet_address: {
      type: String,
      required: true,
    },
    mint: {
      type: String,
      required: true,
      index: true,
    },
    // Amount in SOL per buy
    amount_per_buy: {
      type: Number,
      required: true,
    },
    // Interval in minutes
    interval_minutes: {
      type: Number,
      required: true,
    },
    // Total number of buys to make (optional, 0 for unlimited)
    total_buys: {
      type: Number,
      default: 0,
    },
    // Number of buys completed
    buys_completed: {
      type: Number,
      default: 0,
    },
    // Next buy timestamp
    next_buy_at: {
      type: Date,
      required: true,
    },
    // Status
    status: {
      type: String,
      enum: Object.values(DCAStatusEnum),
      default: DCAStatusEnum.ACTIVE,
    },
    // Created at
    created_at: {
      type: Date,
      default: Date.now,
    },
    // Last buy at
    last_buy_at: {
      type: Date,
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model("dca", DCA);