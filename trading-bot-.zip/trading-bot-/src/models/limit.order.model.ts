/** @format */

import mongoose from "mongoose";
const Schema = mongoose.Schema;

// Limit Order Status Enum
export const LimitOrderStatusEnum = {
  PENDING: "pending",
  TRIGGERED: "triggered",
  FAILED: "failed",
  CANCELLED: "cancelled",
};

// Limit Order Schema - for users to set buy/sell at specific prices
const LimitOrder = new Schema(
  {
    username: {
      type: String,
      required: true,
      index: true,
    },
    wallet_address: {
      type: String,
      required: true,
    },
    mint: {
      type: String,
      required: true,
      index: true,
    },
    // Buy at >= price (SOL per token), Sell at <= price
    order_type: {
      type: String,
      enum: ["buy", "sell"],
      required: true,
    },
    trigger_price: {
      type: Number,
      required: true,
    },
    trigger_price_usd: {
      type: Number,
      default: 0,
    },
    trigger_market_cap: {
      type: Number,
      default: 0,
    },
    // Amount of SOL (for buy) or percentage (for sell 0-100)
    amount: {
      type: Number,
      required: true,
    },
    // Current status
    status: {
      type: String,
      enum: Object.values(LimitOrderStatusEnum),
      default: LimitOrderStatusEnum.PENDING,
    },
    // When was it executed
    executed_at: {
      type: Date,
      default: null,
    },
    executed_price: {
      type: Number,
      default: null,
    },
    // Transaction signature if executed
    tx_signature: {
      type: String,
      default: null,
    },
    // User notes
    notes: {
      type: String,
      default: "",
    },
    // Settings
    auto_cancel_after_hours: {
      type: Number,
      default: 24, // Auto-cancel after 24 hours if not triggered
    },
    slippage: {
      type: Number,
      default: 2.5,
    },
    creation_time: {
      type: Number,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// Index for active orders lookup
LimitOrder.index({ username: 1, status: 1, mint: 1 });
LimitOrder.index({ mint: 1, order_type: 1, status: 1 });

export default mongoose.model("limit_order", LimitOrder);
