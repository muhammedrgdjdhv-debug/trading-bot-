import TelegramBot from "node-telegram-bot-api";
import { UserService } from "../services/user.service";
import { MsgLogService } from "../services/msglog.service";
import { UserTradeSettingService } from "../services/user.trade.setting.service";
import { buyHandler } from "./trade.screen";
import { closeReplyMarkup } from "./common.screen";

export const SNIPER_AMOUNT_TEXT = `🎯 <b>Sniper - Set Amount</b> 🎯\n\n<i>💰 How much SOL to spend on sniping?</i>\n\n<u>Example:</u> Enter <code>0.5</code> for 0.5 SOL per snipe`;

export const SNIPER_SLIPPAGE_TEXT = `🎯 <b>Sniper - Set Slippage</b> 🎯\n\n<i>⚡ Set slippage tolerance (1-100%)</i>\n\n<u>Example:</u> Enter <code>50</code> for 50% slippage`;

// Sniper mode handler
export const sniperModeHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    // Get mint from msglog
    const msglog = await MsgLogService.findOne({
      username,
      msg_id: msg.message_id,
    });
    if (!msglog) {
      await bot.sendMessage(msg.chat.id, "❌ No token selected. Please try again.");
      return;
    }

    await bot.sendMessage(msg.chat.id, SNIPER_AMOUNT_TEXT, {
      parse_mode: "HTML",
      reply_markup: {
        force_reply: true,
      },
    });
  } catch (e) {
    console.log("Sniper mode error:", e);
  }
};

// Set sniper amount
export const sniperSetAmountHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    await bot.sendMessage(msg.chat.id, SNIPER_SLIPPAGE_TEXT, {
      parse_mode: "HTML",
      reply_markup: {
        force_reply: true,
      },
    });
  } catch (e) {
    console.log("Sniper set amount error:", e);
  }
};

// Set sniper slippage
export const sniperSetSlippageHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    await bot.sendMessage(msg.chat.id, SNIPER_SLIPPAGE_TEXT, {
      parse_mode: "HTML",
      reply_markup: {
        force_reply: true,
      },
    });
  } catch (e) {
    console.log("Sniper set slippage error:", e);
  }
};

// Execute sniper
export const executeSniperHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  mint: string,
  amount: number,
  slippage: number
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    // Save original slippage setting
    const originalSlippage = await UserTradeSettingService.getSlippage(username);

    // Set sniper slippage temporarily
    await UserTradeSettingService.setSlippage(username, {
      slippage: slippage,
      slippagebps: slippage * 100, // Convert to basis points
    });

    await bot.sendMessage(
      msg.chat.id,
      `🎯 <b>SNIPER MODE ACTIVATED!</b> 🎯\n\n📈 Token: ${mint.slice(0, 8)}...\n💰 Amount: ${amount} SOL\n⚡ Slippage: ${slippage}%\n\n<i>Attempting to snipe the token...</i>`,
      { parse_mode: "HTML" }
    );

    // Execute the buy with sniper slippage
    await buyHandler(bot, msg, amount);

    // Restore original slippage setting
    await UserTradeSettingService.setSlippage(username, originalSlippage);

    await bot.sendMessage(
      msg.chat.id,
      `✅ <b>Snipe Successful!</b>\n\n🎯 Successfully sniped ${mint.slice(0, 8)}... with ${amount} SOL!`,
      { parse_mode: "HTML" }
    );
  } catch (e) {
    console.log("Execute sniper error:", e);
    await bot.sendMessage(msg.chat.id, "❌ Sniper execution failed.", { parse_mode: "HTML" });
  }
};