import TelegramBot from "node-telegram-bot-api";
import { UserService } from "../services/user.service";
import { Keypair } from "@solana/web3.js";
import bs58 from "bs58";
import { COIN_HUNTER_VERSION } from "../config";
import { copytoclipboard } from "../utils";
import { TokenService } from "../services/token.metadata";
import { contractInfoScreenHandler } from "./contract.info.screen";

const MAX_RETRIES = 5;
export const welcomeKeyboardList = [
  // primary trading options with colored indicators
  [
    { text: "🟢 Buy", command: "trade_buy" },
    { text: "🔴 Sell", command: "trade_sell" },
  ],
  [
    { text: "📊 DCA", command: "trade_dca" },
    { text: "🤝 Copy Trade", command: "trade_copytrade" },
  ],
  [
    { text: "🎯 Sniper", command: "trade_sniper" },
    { text: "⌛ Limit Order", command: "trade_limit" },
  ],
  // existing items
  [
    { text: "📊 Positions", command: "position" },
  ],
  [
    { text: "🛠 Settings & Tools", command: "settings" },
  ],
  [{ text: "🎁 Referral Program", command: "referral" }],
  [
    { text: "🔄 Refresh", command: "refresh_home" },
    { text: "❌ Close", command: "dismiss_message" },
  ],
];

export const WelcomeScreenHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const { username, id: chat_id, first_name, last_name } = msg.chat;
    // check if bot
    if (!username) {
      bot.sendMessage(
        chat_id,
        "⚠️ You have no telegram username. Please take at least one and try it again."
      );
      return;
    }
    const user = await UserService.findOne({ username });
    // if new user, create one
    if (!user) {
      const res = await newUserHandler(bot, msg);
      if (!res) return;
    }
    // send welcome guide
    await welcomeGuideHandler(bot, msg);
    // await bot.deleteMessage(chat_id, msg.message_id);
  } catch (error) {
    console.log("-WelcomeScreenHandler-", error);
  }
};

const newUserHandler = async (bot: TelegramBot, msg: TelegramBot.Message) => {
  const { username, id: chat_id, first_name, last_name } = msg.chat;

  let retries = 0;
  let userdata: any = null;
  let private_key = "";
  let wallet_address = "";

  // find unique private_key
  do {
    const keypair = Keypair.generate();
    private_key = bs58.encode(keypair.secretKey);
    wallet_address = keypair.publicKey.toString();

    const wallet = await UserService.findOne({ wallet_address });
    if (!wallet) {
      // add
      const newUser = {
        chat_id,
        username,
        first_name,
        last_name,
        wallet_address,
        private_key,
      };
      userdata = await UserService.create(newUser); // true; //
    } else {
      retries++;
    }
  } while (retries < MAX_RETRIES && !userdata);

  // impossible to create
  if (!userdata) {
    await bot.sendMessage(
      chat_id,
      "Sorry, we cannot create your account. Please contact support team"
    );
    return false;
  }

  // send private key & wallet address
  const caption =
    `👋 Welcome to Coin Hunter Trading Bot!\n\n` +
    `A new wallet has been generated for you. This is your wallet address\n\n` +
    `${wallet_address}\n\n` +
    `<b>Save this private key below</b>❗\n\n` +
    `<tg-spoiler>${private_key}</tg-spoiler>\n\n` +
    `<b>To get started, please read our documentation</b>`;

  await bot.sendMessage(chat_id, caption, {
    parse_mode: "HTML",
    disable_web_page_preview: true,
    reply_markup: {
      inline_keyboard: [
        [
          {
            text: "* Dismiss message",
            callback_data: JSON.stringify({
              command: "dismiss_message",
            }),
          },
        ],
      ],
    },
  });
  return true;
};

export const welcomeGuideHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  replaceId?: number
) => {
  const { id: chat_id, username } = msg.chat;
  const user = await UserService.findOne({ username });

  if (!user) return;
  const [solbalance, solPrice] = await Promise.all([
    TokenService.getSOLBalance(user.wallet_address),
    TokenService.getSOLPrice(),
  ]);
  const balanceUSD = solPrice > 0 ? ` (~$${(solbalance * solPrice).toFixed(2)})` : '';
  const caption =
    `<b>Welcome to Coin Hunter Trading Bot | Beta Version</b>\n\n` +
    `The Ultimate Solana Trading Bot. Snipe, trade and keep track of your positions with Coin Hunter.\n\n` +
    `⬩ Advanced Trading Tools 🔥\n` +
    `⬩ Multi-Strategy Support (Buy, Sell, DCA, Copy Trade, Sniper, Limit Orders)\n\n` +
    `<b>💳 My Wallet:</b>\n${copytoclipboard(user.wallet_address)}\n\n` +
    `<b>💳 Balance:</b> ${solbalance} SOL${balanceUSD}\n\n` +
    `<a href="https://solscan.io/address/${user.wallet_address}">View on Explorer</a>\n\n` +
    `<b>Professional Solana Trading Bot</b>\n\n` +
    // `-----------------------\n` +
    // `<a href="https://docs.growsol.io/docs">📖 Docs</a>\n` +
    // `<a href="https://growsol.io">🌍 Website</a>\n\n` +
    `<b>Paste a contract address to trigger the Buy/Sell Menu or pick an option to get started.</b>`;

  // const textEventHandler = async (msg: TelegramBot.Message) => {
  //   const receivedChatId = msg.chat.id;
  //   const receivedText = msg.text;
  //   const receivedMessageId = msg.message_id;
  //   const receivedTextSender = msg.chat.username;
  //   // Check if the received message ID matches the original message ID
  //   if (receivedText && receivedChatId === chat_id) {
  //     // message should be same user
  //     if (receivedTextSender === username) {
  //       await contractInfoScreenHandler(bot, msg, receivedText, 'switch_sell');
  //     }
  //     setTimeout(() => { bot.deleteMessage(receivedChatId, receivedMessageId) }, 2000)
  //   }
  //   console.log("Removed");
  //   bot.removeListener('text', textEventHandler);
  // }

  // // Add the 'text' event listener
  // bot.on('text', textEventHandler);

  const reply_markup = {
    inline_keyboard: welcomeKeyboardList.map((rowItem) =>
      rowItem.map((item) => ({
        text: item.text,
        callback_data: JSON.stringify({ command: item.command }),
      }))
    ),
  };

  if (replaceId) {
    try {
      await bot.editMessageText(caption, {
        message_id: replaceId,
        chat_id,
        parse_mode: "HTML",
        disable_web_page_preview: true,
        reply_markup,
      });
    } catch (e: any) {
      if (!e?.message?.includes("message is not modified")) {
        console.log("~welcomeGuideHandler editMessageText~", e?.message);
      }
    }
  } else {
    await bot.sendMessage(chat_id, caption, {
      parse_mode: "HTML",
      disable_web_page_preview: true,
      reply_markup,
    });
  }
};
