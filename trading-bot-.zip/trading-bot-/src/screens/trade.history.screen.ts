import TelegramBot from "node-telegram-bot-api";
import { TradeService } from "../services/trade.service";
import { UserService } from "../services/user.service";
import { TokenService } from "../services/token.metadata";
import { PositionService } from "../services/position.service";
import { TradeTypeEnum } from "../models/index";
import { closeReplyMarkup } from "./common.screen";

// Helper to convert TradeTypeEnum to string
const getTradeTypeStr = (tradeType: number): string => {
  switch (tradeType) {
    case TradeTypeEnum.BUY:
      return "BUY";
    case TradeTypeEnum.SELL:
      return "SELL";
    case TradeTypeEnum.SNIPE:
      return "SNIPE";
    default:
      return "UNKNOWN";
  }
};

// Handler for /trade_history command
export const tradeHistoryScreenHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const username = msg.chat.username;
    if (!username) {
      await bot.sendMessage(
        msg.chat.id,
        "❌ Username not found. Please ensure your Telegram account has a username.",
        closeReplyMarkup
      );
      return;
    }

    const user = await UserService.findOne({ username });
    if (!user) {
      await bot.sendMessage(
        msg.chat.id,
        "❌ User not found in database.",
        closeReplyMarkup
      );
      return;
    }

    const { wallet_address } = user;

    // Get all trades for this user
    const trades = await TradeService.find({ username });

    if (!trades || trades.length === 0) {
      await bot.sendMessage(
        msg.chat.id,
        `💚 <b>Trade History</b> 💚\n\n<i>No trades yet. Start trading to see your history here!</i>`,
        { parse_mode: "HTML", ...closeReplyMarkup }
      );
      return;
    }

    // parse optional command arguments (/trade_history [limit] [page] or /trade_history page N)
    const textParts = msg.text?.split(" ").filter((p) => p.trim() !== "") || [];
    let limit = 10;
    let page = 1;
    if (textParts.length > 1) {
      if (textParts[1].toLowerCase() === "page" && textParts[2]) {
        page = parseInt(textParts[2]) || 1;
      } else {
        limit = parseInt(textParts[1]) || 10;
        if (textParts[2]) {
          page = parseInt(textParts[2]) || 1;
        }
      }
    }
    // clamp values
    limit = Math.min(Math.max(limit, 1), 50);
    page = Math.max(page, 1);

    let text = `💚 <b>TRADE HISTORY</b> 💚\n\n`;
    text += `<b>Total Trades: ${trades.length}</b>\n`;
    text += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

    let totalPNL = 0;
    const enrichedTrades = [];

    // For each trade, get token metadata and calculate PNL
    for (const trade of trades) {
      try {
        const { mint, trade_type, sol_amount, spl_amount, creation_time } = trade;

        // Get token symbol
        let tokenSymbol = "UNKNOWN";
        try {
          const tokenInfo = await TokenService.getMintInfo(mint);
          if (tokenInfo) {
            tokenSymbol = tokenInfo.overview.symbol || "UNK";
          }
        } catch {}

        // calculate PNL using current SPL price for buys, volume data for sells
        let pnl = 0;
        let pnlPercent = 0;
        try {
          const splPrice = (await TokenService.getSPLPrice(mint)) || 0;
          const solPrice = await TokenService.getSOLPrice();

          if (trade_type === TradeTypeEnum.BUY) {
            // estimate current value in SOL using token price
            const currentSolValue = spl_amount * splPrice;
            pnl = currentSolValue - sol_amount;
            if (sol_amount > 0) pnlPercent = (pnl / sol_amount) * 100;
          } else if (trade_type === TradeTypeEnum.SELL) {
            // fallback to volume in position service
            const position = await PositionService.findLastOne({ mint, wallet_address });
            if (position) {
              const { volume } = position;
              pnl = volume;
              if (sol_amount > 0) pnlPercent = (pnl / sol_amount) * 100;
            }
          }
        } catch (e) {
          // ignore calculation errors
        }

        enrichedTrades.push({
          mint,
          tokenSymbol,
          tradeType: getTradeTypeStr(trade_type),
          solAmount: sol_amount,
          splAmount: spl_amount,
          pnl,
          pnlPercent,
          createdAt: new Date(creation_time).toLocaleString(),
        });

        totalPNL += pnl;
      } catch (e) {
        console.error("Error enriching trade:", e);
      }
    }

    // Sort trades by creation time (newest first)
    enrichedTrades.sort((a, b) => {
      const dateA = new Date(a.createdAt).getTime();
      const dateB = new Date(b.createdAt).getTime();
      return dateB - dateA;
    });

    // Pagination
    const startIndex = (page - 1) * limit;
    const displayTrades = enrichedTrades.slice(startIndex, startIndex + limit);

    for (const trade of displayTrades) {
      const tradeEmoji = trade.tradeType === "BUY" ? "🟢" : "🔴";
      const pnlEmoji = trade.pnl >= 0 ? "📈" : "📉";
      const pnlSign = trade.pnl >= 0 ? "+" : "";

      text += `${tradeEmoji} <b>${trade.tradeType}</b> ${trade.tokenSymbol}\n`;
      text += `   Amount: ${trade.solAmount.toFixed(4)} SOL`;
      if (trade.splAmount > 0) {
        text += ` → ${trade.splAmount.toFixed(2)} ${trade.tokenSymbol}`;
      }
      text += `\n`;
      text += `   ${pnlEmoji} PNL: <code>${pnlSign}${trade.pnl.toFixed(4)} SOL (${pnlSign}${trade.pnlPercent.toFixed(2)}%)</code>\n`;
      text += `   📅 ${trade.createdAt}\n`;
      text += `\n`;
    }

    // Summary
    text += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    const totalPNLSign = totalPNL >= 0 ? "+" : "";
    const totalPNLPercent = trades.length > 0 ? (totalPNL / trades.length / 0.01) : 0; // Rough estimate
    text += `📊 <b>Total PNL: ${totalPNLSign}${totalPNL.toFixed(4)} SOL</b>\n`;

    if (enrichedTrades.length > limit) {
      text += `\n<i>Showing ${displayTrades.length} of ${enrichedTrades.length} trades (page ${page})</i>`;
    }

    await bot.sendMessage(msg.chat.id, text, {
      parse_mode: "HTML",
      ...closeReplyMarkup,
    });
  } catch (e) {
    console.error("tradeHistoryScreenHandler error:", e);
    await bot.sendMessage(
      msg.chat.id,
      "❌ Error retrieving trade history. Please try again.",
      closeReplyMarkup
    );
  }
};
