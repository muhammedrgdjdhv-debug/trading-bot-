import TelegramBot from "node-telegram-bot-api";
import { LimitOrderService } from "../services/limit.order.service";
import { UserService } from "../services/user.service";
import { MsgLogService } from "../services/msglog.service";
import { TokenService } from "../services/token.metadata";
import { closeReplyMarkup } from "./common.screen";
import redisClient from "../services/memory.cache";

export const LIMIT_ORDER_PRICE_TEXT = `💚 <b>Limit Order - Set Price Trigger 💚</b>\n\n<i>At what price (SOL per token) should the order trigger?\n\nExamples:\n• Buy trigger at 0.000001 SOL per token → enter <code>0.000001</code>\n• Sell trigger at 0.0001 SOL per token → enter <code>0.0001</code>\n\nEnter 0 to skip price-based trigger and use market cap only.</i>`;

export const LIMIT_ORDER_MCAP_TEXT = `💚 <b>Limit Order - Set Market Cap Trigger 💚</b>\n\n<i>At what market cap (USD) should the order trigger?\n\nExamples:\n• Trigger when market cap reaches $500,000 → enter <code>500000</code>\n• Trigger when market cap drops to $100,000 → enter <code>100000</code>\n\nEnter 0 to skip market cap trigger (use price only).</i>`;

export const LIMIT_ORDER_AMOUNT_TEXT = `💚 <b>Limit Order - Set Amount 💚</b>\n\n<i>How much?\n\n<u>For BUY:</u> Amount in SOL to spend (e.g. <code>0.5</code>)\n<u>For SELL:</u> Percentage of holdings to sell (0-100)</i>`;

const priceKey = (u: string) => `lo_price_${u}`;
const mcapKey = (u: string) => `lo_mcap_${u}`;
const typeKey = (u: string) => `lo_type_${u}`;
const mintKey = (u: string) => `lo_mint_${u}`;
const TTL = 300; // 5 minutes

export const limitOrderChooseTypeHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    const msglog = await MsgLogService.findOne({
      username,
      msg_id: msg.message_id,
    });
    if (!msglog || !msglog.mint) return;

    await redisClient.set(mintKey(username), msglog.mint);
    await redisClient.expire(mintKey(username), TTL);

    const tokenInfo = await TokenService.getMintInfo(msglog.mint);
    const tokenName = tokenInfo?.overview?.name || msglog.mint.slice(0, 8);
    const symbol = tokenInfo?.overview?.symbol || '?';

    await bot.sendMessage(
      msg.chat.id,
      `⌛ <b>Limit Order</b>\n\n<b>Token:</b> ${tokenName} (${symbol})\n\nIs this a <b>Buy</b> or <b>Sell</b> limit order?`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '🟢 Buy limit order',
                callback_data: JSON.stringify({ command: 'lo_type_buy' }),
              },
              {
                text: '🔴 Sell limit order',
                callback_data: JSON.stringify({ command: 'lo_type_sell' }),
              },
            ],
            [
              {
                text: '❌ Cancel',
                callback_data: JSON.stringify({ command: 'dismiss_message' }),
              },
            ],
          ],
        },
      }
    );
  } catch (e) {
    console.error('limitOrderChooseTypeHandler error:', e);
  }
};

export const limitOrderSetOrderTypeHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  orderType: 'buy' | 'sell'
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    await redisClient.set(typeKey(username), orderType);
    await redisClient.expire(typeKey(username), TTL);

    const sentMessage = await bot.sendMessage(msg.chat.id, LIMIT_ORDER_PRICE_TEXT, {
      parse_mode: 'HTML',
      reply_markup: { force_reply: true },
    });

    await MsgLogService.create({
      username,
      mint: (await redisClient.get(mintKey(username))) || '',
      wallet_address: '',
      chat_id: msg.chat.id,
      msg_id: sentMessage.message_id,
      parent_msgid: msg.message_id,
    });
  } catch (e) {
    console.error('limitOrderSetOrderTypeHandler error:', e);
  }
};

export const limitOrderSetPriceHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  price: number
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    await redisClient.set(priceKey(username), String(price));
    await redisClient.expire(priceKey(username), TTL);

    const sentMessage = await bot.sendMessage(msg.chat.id, LIMIT_ORDER_MCAP_TEXT, {
      parse_mode: 'HTML',
      reply_markup: { force_reply: true },
    });

    const mint = (await redisClient.get(mintKey(username))) || '';
    await MsgLogService.create({
      username,
      mint,
      wallet_address: '',
      chat_id: msg.chat.id,
      msg_id: sentMessage.message_id,
      parent_msgid: msg.message_id,
    });
  } catch (e) {
    console.error('limitOrderSetPriceHandler error:', e);
  }
};

export const limitOrderSetMarketCapHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  mcap: number
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    await redisClient.set(mcapKey(username), String(mcap));
    await redisClient.expire(mcapKey(username), TTL);

    const orderType = (await redisClient.get(typeKey(username))) || 'buy';

    const sentMessage = await bot.sendMessage(msg.chat.id, LIMIT_ORDER_AMOUNT_TEXT, {
      parse_mode: 'HTML',
      reply_markup: { force_reply: true },
    });

    const mint = (await redisClient.get(mintKey(username))) || '';
    await MsgLogService.create({
      username,
      mint,
      wallet_address: orderType,
      chat_id: msg.chat.id,
      msg_id: sentMessage.message_id,
      parent_msgid: msg.message_id,
    });
  } catch (e) {
    console.error('limitOrderSetMarketCapHandler error:', e);
  }
};

export const limitOrderProcessAmount = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  amount: number,
  reply_message_id?: number
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const msglog = await MsgLogService.findOne({ username, msg_id: reply_message_id });
    if (!msglog || !msglog.mint) {
      await bot.sendMessage(
        msg.chat.id,
        '❌ Session expired. Please start the limit order again.',
        closeReplyMarkup
      );
      return;
    }

    const mint = msglog.mint;
    const orderType = (msglog.wallet_address as 'buy' | 'sell') || 'buy';

    const priceStr = await redisClient.get(priceKey(username));
    const mcapStr = await redisClient.get(mcapKey(username));
    const triggerPrice = priceStr ? Number(priceStr) : 0;
    const triggerMcap = mcapStr ? Number(mcapStr) : 0;

    if (triggerPrice <= 0 && triggerMcap <= 0) {
      await bot.sendMessage(
        msg.chat.id,
        '❌ You must set at least one trigger: price or market cap. Please start again.',
        closeReplyMarkup
      );
      return;
    }

    if (amount <= 0) {
      await bot.sendMessage(msg.chat.id, '❌ Invalid amount. Please start again.', closeReplyMarkup);
      return;
    }

    const user = await UserService.findOne({ username });
    if (!user) return;

    const tokenInfo = await TokenService.getMintInfo(mint);
    const tokenName = tokenInfo?.overview?.name || mint.slice(0, 8);
    const symbol = tokenInfo?.overview?.symbol || '?';
    const currentPrice = tokenInfo?.overview?.price || 0;

    const order = await LimitOrderService.create({
      username,
      wallet_address: user.wallet_address,
      mint,
      order_type: orderType,
      trigger_price: triggerPrice,
      trigger_market_cap: triggerMcap,
      amount,
      creation_time: Date.now(),
    });

    if (!order) {
      await bot.sendMessage(msg.chat.id, '❌ Failed to create limit order. Please try again.', closeReplyMarkup);
      return;
    }

    await redisClient.del(priceKey(username));
    await redisClient.del(mcapKey(username));
    await redisClient.del(typeKey(username));
    await redisClient.del(mintKey(username));

    const typeEmoji = orderType === 'buy' ? '🟢' : '🔴';
    const triggerLines: string[] = [];
    if (triggerPrice > 0) {
      triggerLines.push(`📌 Price trigger: <b>${triggerPrice} SOL/token</b>`);
    }
    if (triggerMcap > 0) {
      const mcapStr2 = triggerMcap >= 1_000_000
        ? `$${(triggerMcap / 1_000_000).toFixed(2)}M`
        : triggerMcap >= 1_000
        ? `$${(triggerMcap / 1_000).toFixed(1)}K`
        : `$${triggerMcap.toFixed(0)}`;
      triggerLines.push(`📊 Market cap trigger: <b>${mcapStr2}</b>`);
    }

    const confirmText =
      `${typeEmoji} <b>Limit Order Created!</b>\n\n` +
      `<b>Token:</b> ${tokenName} (${symbol})\n` +
      `<b>Type:</b> ${orderType.toUpperCase()}\n` +
      triggerLines.join('\n') + '\n' +
      `<b>Amount:</b> ${amount}${orderType === 'buy' ? ' SOL' : '%'}\n` +
      `<b>Status:</b> ⏳ Pending\n\n` +
      (triggerPrice > 0 && triggerMcap > 0
        ? `<i>Order will trigger when EITHER condition is met.</i>`
        : `<i>Order will trigger when the condition is reached.</i>`);

    await bot.sendMessage(msg.chat.id, confirmText, {
      parse_mode: 'HTML',
      ...closeReplyMarkup,
    });
  } catch (e) {
    console.error('limitOrderProcessAmount error:', e);
  }
};

export const limitOrderDashboardHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    const orders = await LimitOrderService.getActiveOrders(username);

    if (orders.length === 0) {
      await bot.sendMessage(
        msg.chat.id,
        `💚 <b>Limit Orders</b> 💚\n\n<i>No active limit orders.</i>\n\nPaste a contract address, then choose ⌛ Limit Order.`,
        {
          parse_mode: 'HTML',
          ...closeReplyMarkup,
        }
      );
      return;
    }

    let text = `💚 <b>LIMIT ORDERS</b> 💚\n\n<b>Active Orders: ${orders.length}</b>\n\n`;

    for (const order of orders) {
      const orderType = order.order_type.toUpperCase();
      const typeEmoji = order.order_type === 'buy' ? '🟢' : '🔴';
      const statusEmoji = order.status === 'pending' ? '⏳' : '✅';

      text += `${statusEmoji} ${typeEmoji} <b>${orderType}</b>\n`;
      text += `   Token: <code>${order.mint.slice(0, 8)}...${order.mint.slice(-4)}</code>\n`;

      if ((order as any).trigger_price > 0) {
        text += `   📌 Price: <code>${(order as any).trigger_price}</code> SOL/token\n`;
      }
      if ((order as any).trigger_market_cap > 0) {
        const mc = (order as any).trigger_market_cap;
        const mcStr = mc >= 1_000_000
          ? `$${(mc / 1_000_000).toFixed(2)}M`
          : mc >= 1_000
          ? `$${(mc / 1_000).toFixed(1)}K`
          : `$${mc.toFixed(0)}`;
        text += `   📊 MCap: ${mcStr}\n`;
      }

      text += `   Amount: ${order.amount}${order.order_type === 'buy' ? ' SOL' : '%'}\n`;
      text += `   ID: <code>${order._id.toString().slice(-6)}</code>\n\n`;
    }

    const keyboard = {
      inline_keyboard: [
        [
          {
            text: '🔄 Refresh',
            callback_data: JSON.stringify({ command: 'limit_orders_refresh' }),
          },
          {
            text: '❌ Close',
            callback_data: JSON.stringify({ command: 'dismiss_message' }),
          },
        ],
      ],
    };

    await bot.sendMessage(msg.chat.id, text, {
      parse_mode: 'HTML',
      reply_markup: keyboard,
    });
  } catch (e) {
    console.error('limitOrderDashboardHandler error:', e);
  }
};
