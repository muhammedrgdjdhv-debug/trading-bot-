import TelegramBot from "node-telegram-bot-api";
import { LimitOrderService } from "../services/limit.order.service";
import { UserService } from "../services/user.service";
import { MsgLogService } from "../services/msglog.service";
import { TokenService } from "../services/token.metadata";
import { closeReplyMarkup, deleteDelayMessage } from "./common.screen";

export const LIMIT_ORDER_PRICE_TEXT = `💚 <b>Limit Order - Set Price 💚</b>\n\n<i>💲 At what price (SOL per token) should the order trigger?\n\nExample:\n• To buy at 0.000001 SOL: enter <code>0.000001</code>\n• To sell at 0.0001 SOL: enter <code>0.0001</code></i>`;

export const LIMIT_ORDER_AMOUNT_TEXT = `💚 <b>Limit Order - Set Amount 💚</b>\n\n<i>💲 How much?</i>\n\n<u>For BUY:</u> Amount in SOL to spend\n<u>For SELL:</u> Percentage to sell (0-100)`;

// Show active limit orders
export const limitOrderDashboardHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    const orders = await LimitOrderService.getActiveOrders(username);

    if (orders.length === 0) {
      await bot.sendMessage(
        msg.chat.id,
        `💚 <b>Limit Orders</b> 💚\n\n<i>No active limit orders</i>\n\nUse the dashboard to create one!`,
        closeReplyMarkup
      );
      return;
    }

    let text = `💚 <b>LIMIT ORDERS</b> 💚\n\n`;
    text += `<b>Active Orders: ${orders.length}</b>\n\n`;

    for (const order of orders) {
      const orderType = order.order_type.toUpperCase();
      const statusEmoji = order.status === "pending" ? "⏳" : "✅";
      
      text += `${statusEmoji} <b>${orderType}</b> at <code>${order.trigger_price}</code> SOL\n`;
      text += `   Token: ${order.mint.slice(0, 8)}...\n`;
      text += `   Amount: ${order.amount}${order.order_type === "buy" ? " SOL" : "%"}\n`;
      text += `   ID: <code>${order._id.toString().slice(0, 8)}</code>\n\n`;
    }

    const keyboard = {
      inline_keyboard: [
        [
          {
            text: "🔄 Refresh",
            callback_data: JSON.stringify({ command: "limit_orders_refresh" }),
          },
          {
            text: "➕ New Order",
            callback_data: JSON.stringify({ command: "trade_limit" }),
          },
        ],
        [
          {
            text: "❌ Close",
            callback_data: JSON.stringify({ command: "dismiss_message" }),
          },
        ],
      ],
    };

    await bot.sendMessage(msg.chat.id, text, {
      parse_mode: "HTML",
      reply_markup: keyboard,
    });
  } catch (e) {
    console.error("limitOrderDashboardHandler error:", e);
  }
};

// Set price for limit order  
export const limitOrderSetPriceHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const chat_id = msg.chat.id;
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    const msglog = await MsgLogService.findOne({
      username,
      msg_id: msg.message_id,
    });
    if (!msglog) return;

    const { mint } = msglog;
    if (!mint) return;

    // For now, just send the price input prompt
    // In a real implementation, we'd also need to know if it's a buy or sell
    const sentMessage = await bot.sendMessage(chat_id, LIMIT_ORDER_PRICE_TEXT, {
      parse_mode: "HTML",
      reply_markup: {
        force_reply: true,
      },
    });

    await MsgLogService.create({
      username,
      mint,
      wallet_address: user.wallet_address,
      chat_id,
      msg_id: sentMessage.message_id,
      parent_msgid: msg.message_id,
    });
  } catch (e) {
    console.error("limitOrderSetPriceHandler error:", e);
  }
};

// Set amount for limit order
export const limitOrderSetAmountHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  price: number
) => {
  try {
    const chat_id = msg.chat.id;
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    const msglog = await MsgLogService.findOne({
      username,
      msg_id: msg.message_id,
    });
    if (!msglog) return;

    const { mint } = msglog;
    if (!mint) return;

    // Show the amount input screen
    const sentMessage = await bot.sendMessage(chat_id, LIMIT_ORDER_AMOUNT_TEXT, {
      parse_mode: "HTML",
      reply_markup: {
        force_reply: true,
      },
    });

    await MsgLogService.create({
      username,
      mint,
      wallet_address: user.wallet_address,
      chat_id,
      msg_id: sentMessage.message_id,
      parent_msgid: msg.message_id,
    });
  } catch (e) {
    console.error("limitOrderSetAmountHandler error:", e);
  }
};

// Process the amount input and create the limit order
export const limitOrderProcessAmount = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  amount: number,
  reply_message_id?: number
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    // Find the MsgLog entry for the amount prompt
    const msglog = await MsgLogService.findOne({ username, msg_id: reply_message_id });
    if (!msglog) {
      await bot.sendMessage(msg.chat.id, "❌ Could not find the limit order context. Please start again.", closeReplyMarkup);
      return;
    }

    const { mint, trigger_price } = msglog as any;
    if (!mint || !trigger_price) {
      await bot.sendMessage(msg.chat.id, "❌ Missing token or trigger price. Please start again.", closeReplyMarkup);
      return;
    }

    // Default to BUY order for now
    const orderType: "buy" | "sell" = "buy";

    // Create the limit order
    await createLimitOrderHandler(bot, msg, orderType, Number(trigger_price), amount);
  } catch (e) {
    console.error("limitOrderProcessAmount error:", e);
  }
};

// Create the limit order
export const createLimitOrderHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  orderType: "buy" | "sell",
  price: number,
  amount: number
) => {
  try {
    const chat_id = msg.chat.id;
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    const msglog = await MsgLogService.findOne({
      username,
      msg_id: msg.message_id,
    });
    if (!msglog) return;

    const { mint } = msglog;
    if (!mint) return;

    // Validate inputs
    if (price <= 0 || amount <= 0) {
      await bot.sendMessage(chat_id, "❌ Invalid price or amount", closeReplyMarkup);
      return;
    }

    // Get token info for context
    const tokenInfo = await TokenService.getMintInfo(mint);
    const tokenName = tokenInfo?.overview?.name || mint.slice(0, 8);

    // Create the limit order
    const order = await LimitOrderService.create({
      username,
      wallet_address: user.wallet_address,
      mint,
      order_type: orderType,
      trigger_price: price,
      amount,
      creation_time: Date.now(),
    });

    if (!order) {
      await bot.sendMessage(chat_id, "❌ Failed to create limit order", closeReplyMarkup);
      return;
    }

    // Send confirmation
    let confirmText = `💚 <b>Limit Order Created!</b> 💚\n\n`;
    confirmText += `<b>Type:</b> ${orderType.toUpperCase()}\n`;
    confirmText += `<b>Token:</b> ${tokenName}\n`;
    confirmText += `<b>Trigger Price:</b> ${price} SOL per token\n`;
    confirmText += `<b>Amount:</b> ${amount}${orderType === "buy" ? " SOL" : "%"}\n`;
    confirmText += `<b>Status:</b> ⏳ Pending\n\n`;
    confirmText += `<i>Order will trigger when the token price reaches your specified value.</i>`;

    await bot.sendMessage(chat_id, confirmText, closeReplyMarkup);
  } catch (e) {
    console.error("createLimitOrderHandler error:", e);
  }
};
