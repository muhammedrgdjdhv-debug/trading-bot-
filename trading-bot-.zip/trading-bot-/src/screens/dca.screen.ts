import TelegramBot from "node-telegram-bot-api";
import { DCAService } from "../services/dca.service";
import { UserService } from "../services/user.service";
import { MsgLogService } from "../services/msglog.service";
import { closeReplyMarkup } from "./common.screen";

export const DCA_AMOUNT_TEXT = `💚 <b>DCA - Set Amount 💚</b>\n\n<i>💲 How much SOL to invest per DCA buy?</i>\n\n<u>Example:</u> Enter <code>0.1</code> for 0.1 SOL per buy`;

export const DCA_INTERVAL_TEXT = `💚 <b>DCA - Set Interval 💚</b>\n\n<i>⏰ How often to buy? (in minutes)</i>\n\n<u>Example:</u> Enter <code>60</code> for every hour`;

// DCA Dashboard
export const dcaDashboardHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    const dcas = await DCAService.getActiveDCAs(username);

    if (dcas.length === 0) {
      await bot.sendMessage(
        msg.chat.id,
        `💚 <b>Dollar-Cost Averaging (DCA)</b> 💚\n\n<i>DCA helps you buy tokens at regular intervals to average out your entry price.</i>\n\n<b>No active DCA plans</b>\n\nUse the contract info screen to set up DCA for a token!`,
        closeReplyMarkup
      );
      return;
    }

    let text = `💚 <b>DCA PLANS</b> 💚\n\n`;
    text += `<b>Active Plans: ${dcas.length}</b>\n\n`;

    for (const dca of dcas) {
      text += `📈 <b>${dca.mint.slice(0, 8)}...</b>\n`;
      text += `   Amount: ${dca.amount_per_buy} SOL\n`;
      text += `   Interval: ${dca.interval_minutes} min\n`;
      text += `   Completed: ${dca.buys_completed}\n`;
      text += `   Next: ${dca.next_buy_at.toLocaleString()}\n`;
      text += `   ID: <code>${dca._id.toString().slice(0, 8)}</code>\n\n`;
    }

    const keyboard = {
      inline_keyboard: [
        [{ text: "🔄 Refresh", callback_data: JSON.stringify({ command: "dca_refresh" }) }],
        [{ text: "❌ Close", callback_data: JSON.stringify({ command: "dismiss_message" }) }],
      ],
    };

    await bot.sendMessage(msg.chat.id, text, {
      parse_mode: "HTML",
      reply_markup: keyboard,
    });
  } catch (e) {
    console.log("DCA dashboard error:", e);
  }
};

// Set DCA amount
export const dcaSetAmountHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    // Get mint from msglog
    const msglog = await MsgLogService.findOne({
      username,
      msg_id: msg.message_id,
    });
    if (!msglog) return;

    await bot.sendMessage(msg.chat.id, DCA_AMOUNT_TEXT, {
      parse_mode: "HTML",
      reply_markup: {
        force_reply: true,
      },
    });
  } catch (e) {
    console.log("DCA set amount error:", e);
  }
};

// Set DCA interval
export const dcaSetIntervalHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    await bot.sendMessage(msg.chat.id, DCA_INTERVAL_TEXT, {
      parse_mode: "HTML",
      reply_markup: {
        force_reply: true,
      },
    });
  } catch (e) {
    console.log("DCA set interval error:", e);
  }
};

// Create DCA plan
export const createDCAHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  mint: string,
  amount: number,
  interval: number
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    await DCAService.createDCA({
      username,
      wallet_address: user.wallet_address,
      mint,
      amount_per_buy: amount,
      interval_minutes: interval,
    });

    await bot.sendMessage(
      msg.chat.id,
      `✅ <b>DCA Plan Created!</b>\n\n📈 Token: ${mint.slice(0, 8)}...\n💰 Amount per buy: ${amount} SOL\n⏰ Interval: ${interval} minutes\n\nThe bot will automatically buy for you at the set intervals.`,
      { parse_mode: "HTML" }
    );
  } catch (e) {
    console.log("Create DCA error:", e);
    await bot.sendMessage(msg.chat.id, "❌ Failed to create DCA plan.", { parse_mode: "HTML" });
  }
};