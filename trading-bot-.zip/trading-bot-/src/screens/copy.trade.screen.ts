import TelegramBot from "node-telegram-bot-api";
import { CopyTradeService } from "../services/copy.trade.service";
import { UserService } from "../services/user.service";
import { MsgLogService } from "../services/msglog.service";
import { closeReplyMarkup } from "./common.screen";

export const COPY_TRADE_WALLET_TEXT = `💚 <b>Copy Trade - Source Wallet</b> 💚\n\n<i>🔐 Paste the wallet address you want to copy trades from:</i>`;

// Show active copy trades
export const copyTradeDashboardHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    const trades = await CopyTradeService.getActiveByUser(username);

    if (trades.length === 0) {
      await bot.sendMessage(
        msg.chat.id,
        `💚 <b>Copy Trades</b> 💚\n\n<i>No active copy trades</i>\n\nAdd one to start copying trades from other wallets!`,
        closeReplyMarkup
      );
      return;
    }

    let text = `💚 <b>COPY TRADES</b> 💚\n\n`;
    text += `<b>Active: ${trades.length}</b>\n\n`;

    const keyboardRows: Array<any> = [];
    for (const trade of trades) {
      const modeEmoji =
        trade.copy_mode === "mirror"
          ? "🔄"
          : trade.copy_mode === "scalable"
          ? "📊"
          : trade.copy_mode === "fixed"
          ? "💰"
          : "⚙️";

      const statusEmoji =
        trade.status === "active"
          ? "🟢"
          : trade.status === "paused"
          ? "🟡"
          : "🔴";

      text += `${statusEmoji} <b>Source:</b> ${trade.source_wallet_label || trade.source_wallet.slice(0, 8)}...\n`;
      text += `${modeEmoji} <b>Mode:</b> ${trade.copy_mode}${trade.full_copy ? " (full)" : ""}`;

      if (trade.copy_mode === "scalable") {
        text += ` (${(trade.scale_factor * 100).toFixed(0)}%)`;
      } else if (trade.copy_mode === "fixed") {
        text += ` (${trade.fixed_amount} SOL/trade)`;
      }

      // settings info
      text += `\nTP: ${trade.take_profit_percent > 0 ? trade.take_profit_percent + "%" : "Disabled"}`;
      text += ` | SL: ${trade.stop_loss_percent > 0 ? trade.stop_loss_percent + "%" : "Disabled"}`;
      text += `\nBuys: ${trade.copy_buys ? "✅" : "❌"} | Sells: ${trade.copy_sells ? "✅" : "❌"}`;

      text += `\n📊 <b>Trades:</b> ${trade.total_copied_trades} | `;
      text += `🎯 <b>PNL:</b> ${trade.total_pnl_percent.toFixed(2)}% (${trade.total_pnl.toFixed(4)} SOL)\n\n`;

      keyboardRows.push([
        {
          text: "⚙️ Manage",
          callback_data: JSON.stringify({ command: "copytrade_manage", id: trade._id }),
        },
      ]);
    }

    const keyboard = {
      inline_keyboard: [
        ...keyboardRows,
        [
          {
            text: "🔄 Refresh",
            callback_data: JSON.stringify({ command: "copytrade_refresh" }),
          },
          {
            text: "➕ Add Wallet",
            callback_data: JSON.stringify({ command: "trade_copytrade" }),
          },
        ],
        [
          {
            text: "❌ Close",
            callback_data: JSON.stringify({ command: "dismiss_message" }),
          },
        ],
      ],
    };

    await bot.sendMessage(msg.chat.id, text, {
      parse_mode: "HTML",
      reply_markup: keyboard,
    });
  } catch (e) {
    console.error("copyTradeDashboardHandler error:", e);
  }
};

// Set source wallet for copy trade
export const copyTradeSetSourceWalletHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  try {
    const chat_id = msg.chat.id;
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    const text = `💚 <b>Copy Trade - Source Wallet</b> 💚\n\n<i>🔐 Paste the wallet address you want to copy trades from:</i>`;

    const sentMessage = await bot.sendMessage(chat_id, text, {
      parse_mode: "HTML",
      reply_markup: {
        force_reply: true,
      },
    });
  } catch (e) {
    console.error("copyTradeSetSourceWalletHandler error:", e);
  }
};

// Set copy mode
export const copyTradeSetModeHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  sourceWallet: string
) => {
  try {
    const chat_id = msg.chat.id;

    const keyboard = {
      inline_keyboard: [
        [
          {
            text: "🔄 Mirror (1:1)",
            callback_data: JSON.stringify({
              command: "copytrade_mode_mirror",
              source: sourceWallet,
            }),
          },
        ],
        [
          {
            text: "⚡ Full Copy",
            callback_data: JSON.stringify({
              command: "copytrade_mode_full",
              source: sourceWallet,
            }),
          },
        ],
        [
          {
            text: "📊 Scalable (%)",
            callback_data: JSON.stringify({
              command: "copytrade_mode_scalable",
              source: sourceWallet,
            }),
          },
        ],
        [
          {
            text: "💰 Fixed Amount",
            callback_data: JSON.stringify({
              command: "copytrade_mode_fixed",
              source: sourceWallet,
            }),
          },
        ],
      ],
    };

    const text = `💚 <b>Copy Mode</b> 💚\n\n` +
      `🔄 <b>Mirror:</b> 1:1 copy of trades\n` +
      `📊 <b>Scalable:</b> Scale by percentage (0.5x, 1x, 2x)\n` +
      `💰 <b>Fixed:</b> Fixed SOL per trade\n\nChoose your copy mode:`;

    await bot.sendMessage(chat_id, text, {
      parse_mode: "HTML",
      reply_markup: keyboard,
    });
  } catch (e) {
    console.error("copyTradeSetModeHandler error:", e);
  }
};

// Create copy trade
export const createCopyTradeHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  data: {
    sourceWallet: string;
    sourceLabel?: string;
    mode: "mirror" | "scalable" | "fixed";
    scaleFactor?: number; // for scalable mode
    fixedAmount?: number; // for fixed mode
    fullCopy?: boolean; // whether user chose full copy option
  }
) => {
  try {
    const chat_id = msg.chat.id;
    const username = msg.chat.username;
    if (!username) return;

    const user = await UserService.findOne({ username });
    if (!user) return;

    // Create the copy trade
    const copyTrade = await CopyTradeService.create({
      username,
      wallet_address: user.wallet_address,
      source_wallet: data.sourceWallet,
      source_wallet_label: data.sourceLabel || data.sourceWallet.slice(0, 8),
      copy_mode: data.mode,
      scale_factor: data.scaleFactor || 1.0,
      fixed_amount: data.fixedAmount || 0,
      full_copy: data.fullCopy || false,
      creation_time: Date.now(),
    });

    if (!copyTrade) {
      await bot.sendMessage(chat_id, "❌ Failed to create copy trade", closeReplyMarkup);
      return;
    }

    // Send confirmation
    let confirmText = `💚 <b>Copy Trade Created!</b> 💚\n\n`;
    confirmText += `<b>Source:</b> ${data.sourceLabel || data.sourceWallet.slice(0, 16)}...\n`;
    confirmText += `<b>Mode:</b> ${data.mode}${data.fullCopy ? " (full copy)" : ""}`;

    if (data.mode === "scalable") {
      confirmText += ` (${(data.scaleFactor! * 100).toFixed(0)}%)`;
    } else if (data.mode === "fixed") {
      confirmText += ` (${data.fixedAmount} SOL per trade)`;
    }

    confirmText += `\n<b>Status:</b> 🟢 Active\n\n`;
    confirmText += `<i>Trades from this wallet will now be copied automatically!</i>`;

    await bot.sendMessage(chat_id, confirmText, closeReplyMarkup);
  } catch (e) {
    console.error("createCopyTradeHandler error:", e);
  }
};

// Pause copy trade
export const pauseCopyTradeHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  copyTradeId: string
) => {
  try {
    const chat_id = msg.chat.id;

    const trade = await CopyTradeService.pause(copyTradeId);
    if (!trade) {
      await bot.sendMessage(chat_id, "❌ Failed to pause copy trade", closeReplyMarkup);
      return;
    }

    await bot.sendMessage(chat_id, `🟡 Copy trade paused. Tap to resume trading from this wallet.`, closeReplyMarkup);
  } catch (e) {
    console.error("pauseCopyTradeHandler error:", e);
  }
};

// Resume copy trade
export const resumeCopyTradeHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  copyTradeId: string
) => {
  try {
    const chat_id = msg.chat.id;

    const trade = await CopyTradeService.resume(copyTradeId);
    if (!trade) {
      await bot.sendMessage(chat_id, "❌ Failed to resume copy trade", closeReplyMarkup);
      return;
    }

    await bot.sendMessage(chat_id, `🟢 Copy trade resumed. Now copying trades!`, closeReplyMarkup);
  } catch (e) {
    console.error("resumeCopyTradeHandler error:", e);
  }
};

// Stop copy trade
export const stopCopyTradeHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  copyTradeId: string
) => {
  try {
    const chat_id = msg.chat.id;

    const trade = await CopyTradeService.stop(copyTradeId);
    if (!trade) {
      await bot.sendMessage(chat_id, "❌ Failed to stop copy trade", closeReplyMarkup);
      return;
    }

    await bot.sendMessage(chat_id, `🔴 Copy trade stopped. Will no longer copy from this wallet.`, closeReplyMarkup);
  } catch (e) {
    console.error("stopCopyTradeHandler error:", e);
  }
};

// Set take profit for copy trade
export const copyTradeSetTPHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  copyTradeId: string
) => {
  try {
    const chat_id = msg.chat.id;

    const text = `🎯 <b>Take Profit (%)</b> 🎯\n\n` +
      `<i>Set the profit percentage at which to auto-sell</i>\n\n` +
      `<u>Example:</u> Enter <code>50</code> to sell at 50% profit\n` +
      `Enter <code>0</code> to disable take profit`;

    const sentMessage = await bot.sendMessage(chat_id, text, {
      parse_mode: "HTML",
      reply_markup: {
        force_reply: true,
      },
    });

    // log for reply handling
    await MsgLogService.create({
      username: msg.chat.username || "",
      chat_id,
      msg_id: sentMessage.message_id,
      wallet_address: copyTradeId,
      extra_key: "copytrade_tp",
    });
  } catch (e) {
    console.error("copyTradeSetTPHandler error:", e);
  }
};

// Set stop loss for copy trade
export const copyTradeSetSLHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  copyTradeId: string
) => {
  try {
    const chat_id = msg.chat.id;

    const text = `🛑 <b>Stop Loss (%)</b> 🛑\n\n` +
      `<i>Set the loss percentage at which to auto-sell</i>\n\n` +
      `<u>Example:</u> Enter <code>20</code> to sell at 20% loss\n` +
      `Enter <code>0</code> to disable stop loss`;

    const sentMessage = await bot.sendMessage(chat_id, text, {
      parse_mode: "HTML",
      reply_markup: {
        force_reply: true,
      },
    });

    await MsgLogService.create({
      username: msg.chat.username || "",
      chat_id,
      msg_id: sentMessage.message_id,
      wallet_address: copyTradeId,
      extra_key: "copytrade_sl",
    });
  } catch (e) {
    console.error("copyTradeSetSLHandler error:", e);
  }
};

// Toggle buy/sell copying
export const copyTradeToggleBuySellHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  copyTradeId: string
) => {
  try {
    const chat_id = msg.chat.id;

    const trade = await CopyTradeService.findOne(copyTradeId);
    if (!trade) {
      await bot.sendMessage(chat_id, "❌ Copy trade not found", closeReplyMarkup);
      return;
    }

    // optional action buttons depending on status
    const actionRow: any[] = [];
    if (trade.status === "active") {
      actionRow.push({
        text: "⏸ Pause",
        callback_data: JSON.stringify({ command: "copytrade_pause", id: copyTradeId }),
      });
    } else if (trade.status === "paused") {
      actionRow.push({
        text: "▶️ Resume",
        callback_data: JSON.stringify({ command: "copytrade_resume", id: copyTradeId }),
      });
    }
    actionRow.push({
      text: "🛑 Stop",
      callback_data: JSON.stringify({ command: "copytrade_stop", id: copyTradeId }),
    });

    const keyboard = {
      inline_keyboard: [
        [
          {
            text: `${trade.copy_buys ? "✅" : "❌"} Copy Buys`,
            callback_data: JSON.stringify({
              command: "copytrade_toggle_buys",
              id: copyTradeId,
            }),
          },
        ],
        [
          {
            text: `${trade.copy_sells ? "✅" : "❌"} Copy Sells`,
            callback_data: JSON.stringify({
              command: "copytrade_toggle_sells",
              id: copyTradeId,
            }),
          },
        ],
        [
          {
            text: "🎯 Set TP",
            callback_data: JSON.stringify({ command: "copytrade_set_tp", id: copyTradeId }),
          },
          {
            text: "🛑 Set SL",
            callback_data: JSON.stringify({ command: "copytrade_set_sl", id: copyTradeId }),
          },
        ],
        actionRow,
        [
          {
            text: "❌ Close",
            callback_data: JSON.stringify({ command: "dismiss_message" }),
          },
        ],
      ],
    };

    const text = `⚙️ <b>Copy Trade Settings</b> ⚙️\n\n` +
      `Copy buys: ${trade.copy_buys ? "✅ Enabled" : "❌ Disabled"}\n` +
      `Copy sells: ${trade.copy_sells ? "✅ Enabled" : "❌ Disabled"}\n` +
      `TP: ${trade.take_profit_percent > 0 ? trade.take_profit_percent + "%" : "Disabled"}\n` +
      `SL: ${trade.stop_loss_percent > 0 ? trade.stop_loss_percent + "%" : "Disabled"}`;

    await bot.sendMessage(chat_id, text, {
      parse_mode: "HTML",
      reply_markup: keyboard,
    });
  } catch (e) {
    console.error("copyTradeToggleBuySellHandler error:", e);
  }
};
