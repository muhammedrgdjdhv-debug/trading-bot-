import TelegramBot from "node-telegram-bot-api";
import { showWelcomeReferralProgramMessage } from "./welcome.referral.screen";
import { generateReferralCode } from "../utils";
import { UserService } from "../services/user.service";
import { UserSchema } from "../models/index";

export const OpenReferralWindowHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  const chat = msg.chat;
  const username = chat.username;
  if (!username) {
    await bot.sendMessage(chat.id,
      "⚠️ You need a Telegram username to use the referral program. Please set one in your Telegram settings and try again.",
      { parse_mode: "HTML" }
    );
    return;
  }

  const referrerCode = await GenerateReferralCode(username);
  showWelcomeReferralProgramMessage(bot, chat, referrerCode);
};

export const GenerateReferralCode = async (username: string): Promise<string | undefined> => {
  const userInfo = await UserService.findOne({ username });
  if (!userInfo) return undefined;

  // Return existing code if already assigned
  if (userInfo.referrer_code && userInfo.referrer_code !== '') {
    return userInfo.referrer_code;
  }

  // Generate a unique code — retry until there is no collision
  let uniquecode = generateReferralCode(10);
  let collision = await UserSchema.findOne({ referrer_code: uniquecode });
  let attempts = 0;
  while (collision && attempts < 10) {
    uniquecode = generateReferralCode(10);
    collision = await UserSchema.findOne({ referrer_code: uniquecode });
    attempts++;
  }

  // Save directly to the user model — no external API needed
  await UserService.updateMany(
    { username },
    { referrer_code: uniquecode }
  );

  console.log(`Referral code created for @${username}: ${uniquecode}`);
  return uniquecode;
};
