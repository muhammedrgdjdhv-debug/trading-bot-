import TelegramBot from "node-telegram-bot-api";
import { Keypair } from "@solana/web3.js";
import * as bip39 from "bip39";
import bs58 from "bs58";
import { isValidWalletAddress } from "../utils";
import { contractInfoScreenHandler } from "../screens/contract.info.screen";
import {
  AUTO_BUY_TEXT,
  BUY_XSOL_TEXT,
  PRESET_BUY_TEXT,
  SELL_XPRO_TEXT,
  SET_GAS_FEE,
  SET_JITO_FEE,
  SET_SLIPPAGE_TEXT,
  WITHDRAW_TOKEN_AMT_TEXT,
  WITHDRAW_XTOKEN_TEXT,
} from "../bot.opts";
import {
  buyHandler,
  buyPreviewHandler,
  sellHandler,
  setSlippageHandler,
} from "../screens/trade.screen";
import {
  limitOrderSetAmountHandler,
  limitOrderProcessAmount,
  LIMIT_ORDER_PRICE_TEXT,
  LIMIT_ORDER_AMOUNT_TEXT,
} from "../screens/limit.order.screen";
import {
  DCA_AMOUNT_TEXT,
  DCA_INTERVAL_TEXT,
  dcaSetIntervalHandler,
  createDCAHandler,
} from "../screens/dca.screen";
import {
  SNIPER_AMOUNT_TEXT,
  SNIPER_SLIPPAGE_TEXT,
  sniperSetAmountHandler,
  sniperSetSlippageHandler,
  executeSniperHandler,
} from "../screens/sniper.screen";
import {
  copyTradeSetModeHandler,
  createCopyTradeHandler,
  COPY_TRADE_WALLET_TEXT,
} from "../screens/copy.trade.screen";
import { closeReplyMarkup } from "../screens/common.screen";
import { CopyTradeService } from "../services/copy.trade.service";
import {
  withdrawAddressHandler,
  withdrawHandler,
} from "../screens/transfer.funds";
import {
  presetBuyBtnHandler,
  setCustomAutoBuyAmountHandler,
  setCustomBuyPresetHandler,
  setCustomFeeHandler,
  setCustomJitoFeeHandler,
  walletViewHandler,
} from "../screens/settings.screen";
import { MsgLogService } from "../services/msglog.service";
import redisClient from "../services/redis";
import { UserService } from "../services/user.service";
import { MAX_WALLET } from "../config";

export const messageHandler = async (
  bot: TelegramBot,
  msg: TelegramBot.Message
) => {
  console.log("Message received:", msg.text);
  try {
    const messageText = msg.text?.trim();
    const { reply_to_message } = msg;
    const username = msg.chat.username;

    if (!messageText) return;
    if (!username) return;

    // If user sends a full 64-byte base58 private key directly (without replying),
    // treat it as an import. 32-byte strings are NOT auto-detected because they
    // are indistinguishable from Solana wallet addresses.
    const users = await UserService.findAndSort({ username });
    const activeUser = users.filter((user) => user.retired === false)[0];
    const is64ByteKey = (() => {
      try {
        const buf = bs58.decode(messageText);
        return buf.length === 64;
      } catch {
        return false;
      }
    })();

    if (is64ByteKey && !reply_to_message) {
      await processImportPrivateKey(bot, msg, messageText);
      return;
    }

    if (reply_to_message && reply_to_message.text) {
      const { text } = reply_to_message;
      // if number, input amount
      const regex = /^[0-9]+(\.[0-9]+)?$/;
      const isNumber = regex.test(messageText) === true;
      const reply_message_id = reply_to_message.message_id;

      if (isNumber) {
        const amount = Number(messageText);

            if (text === BUY_XSOL_TEXT.replace(/<[^>]*>/g, "")) {
          await buyPreviewHandler(bot, msg, amount, reply_message_id);
        } else if (text === SELL_XPRO_TEXT.replace(/<[^>]*>/g, "")) {
          await sellHandler(bot, msg, amount, reply_message_id);
        } else if (text === WITHDRAW_XTOKEN_TEXT.replace(/<[^>]*>/g, "")) {
          await withdrawHandler(bot, msg, messageText, reply_message_id);
        } else if (text === SET_SLIPPAGE_TEXT.replace(/<[^>]*>/g, "")) {
          await setSlippageHandler(bot, msg, amount, reply_message_id);
        } else if (text === PRESET_BUY_TEXT.replace(/<[^>]*>/g, "")) {
          await setCustomBuyPresetHandler(bot, msg, amount, reply_message_id);
        } else if (text === AUTO_BUY_TEXT.replace(/<[^>]*>/g, "")) {
          await setCustomAutoBuyAmountHandler(
            bot,
            msg,
            amount,
            reply_message_id
          );
        } else if (text === SET_GAS_FEE.replace(/<[^>]*>/g, "")) {
          await setCustomFeeHandler(bot, msg, amount, reply_message_id);
        } else if (text === SET_JITO_FEE.replace(/<[^>]*>/g, "")) {
          if (amount > 0.0001) {
            await setCustomJitoFeeHandler(bot, msg, amount, reply_message_id);
          } else {
            await setCustomJitoFeeHandler(bot, msg, 0.0001, reply_message_id);
          }
        } else if (text === LIMIT_ORDER_PRICE_TEXT.replace(/<[^>]*>/g, "")) {
          const price = Number(messageText);
          await limitOrderSetAmountHandler(bot, msg, price);
        } else if (text === LIMIT_ORDER_AMOUNT_TEXT.replace(/<[^>]*>/g, "")) {
          const amount2 = Number(messageText);
          await limitOrderProcessAmount(bot, msg, amount2, reply_message_id);
        } else if (text === DCA_AMOUNT_TEXT.replace(/<[^>]*>/g, "")) {
          const amount = Number(messageText);
          if (isNaN(amount) || amount <= 0) {
            await bot.sendMessage(msg.chat.id, "❌ Invalid amount. Please enter a positive number.");
            return;
          }
          // Store amount in cache + expiry
          const dcaAmountKey = `dca_amount_${username}`;
          await redisClient.set(dcaAmountKey, amount.toString());
          await redisClient.expire(dcaAmountKey, 300); // 5 min expiry
          await dcaSetIntervalHandler(bot, msg);
        } else if (text === DCA_INTERVAL_TEXT.replace(/<[^>]*>/g, "")) {
          const interval = Number(messageText);
          if (isNaN(interval) || interval <= 0) {
            await bot.sendMessage(msg.chat.id, "❌ Invalid interval. Please enter a positive number in minutes.");
            return;
          }
          // Get amount from cache
          const dcaAmountKey = `dca_amount_${username}`;
          const amountStr = await redisClient.get(dcaAmountKey);
          if (!amountStr) {
            await bot.sendMessage(msg.chat.id, "❌ Session expired. Please start DCA setup again.");
            return;
          }
          const amount = Number(amountStr);
          // Get mint from msglog
          const msglog = await MsgLogService.findOne({
            username,
            msg_id: reply_message_id,
          });
          if (!msglog) {
            await bot.sendMessage(msg.chat.id, "❌ Could not find token. Please try again.");
            return;
          }
          await createDCAHandler(bot, msg, msglog.mint, amount, interval);
        } else if (text === SNIPER_AMOUNT_TEXT.replace(/<[^>]*>/g, "")) {
          const amount = Number(messageText);
          if (isNaN(amount) || amount <= 0) {
            await bot.sendMessage(msg.chat.id, "❌ Invalid amount. Please enter a positive number.");
            return;
          }
          // Store amount in cache + expiry
          const sniperAmountKey = `sniper_amount_${username}`;
          await redisClient.set(sniperAmountKey, amount.toString());
          await redisClient.expire(sniperAmountKey, 300); // 5 min expiry
          await sniperSetSlippageHandler(bot, msg);
        } else if (text === SNIPER_SLIPPAGE_TEXT.replace(/<[^>]*>/g, "")) {
          const slippage = Number(messageText);
          if (isNaN(slippage) || slippage < 0 || slippage > 100) {
            await bot.sendMessage(msg.chat.id, "❌ Invalid slippage. Please enter a value between 0 and 100.");
            return;
          }
          // Get amount from cache
          const sniperAmountKey = `sniper_amount_${username}`;
          const amountStr = await redisClient.get(sniperAmountKey);
          if (!amountStr) {
            await bot.sendMessage(msg.chat.id, "❌ Session expired. Please start sniper setup again.");
            return;
          }
          const amount = Number(amountStr);
          // Get mint from msglog
          const msglog = await MsgLogService.findOne({
            username,
            msg_id: reply_message_id,
          });
          if (!msglog) {
            await bot.sendMessage(msg.chat.id, "❌ Could not find token. Please try again.");
            return;
          }
          await executeSniperHandler(bot, msg, msglog.mint, amount, slippage);
        }

        // if we reach here none of the hardcoded flows matched; check for copy trade / tp / sl via msglog
        else {
          const msglog = await MsgLogService.findOne({
            username,
            msg_id: reply_message_id,
          });
          if (msglog && msglog.extra_key) {
            if (msglog.extra_key === "import_private_key") {
              await processImportPrivateKey(bot, msg, messageText);
              return;
            } else if (msglog.extra_key === "import_seed_12") {
              await processImportSeedPhrase(bot, msg, messageText, 12);
              return;
            } else if (msglog.extra_key === "import_seed_24") {
              await processImportSeedPhrase(bot, msg, messageText, 24);
              return;
            } else if (msglog.extra_key === "copytrade_scale") {
              const source = msglog.mint;
              const factor = amount / 100;
              await createCopyTradeHandler(bot, msg, {
                sourceWallet: source,
                mode: "scalable",
                scaleFactor: factor,
                fullCopy: false,
              });
              return;
            } else if (msglog.extra_key === "copytrade_fixed") {
              const source = msglog.mint;
              await createCopyTradeHandler(bot, msg, {
                sourceWallet: source,
                mode: "fixed",
                fixedAmount: amount,
                fullCopy: false,
              });
              return;
            } else if (msglog.extra_key === "copytrade_tp") {
              const id = msglog.wallet_address;
              if (isNaN(amount) || amount < 0) {
                await bot.sendMessage(msg.chat.id, "❌ Invalid percent. Please enter a non-negative number.", closeReplyMarkup);
                return;
              }
              await CopyTradeService.setTakeProfit(id, amount);
              await bot.sendMessage(msg.chat.id, `✅ Take profit updated to ${amount}%`, closeReplyMarkup);
              return;
            } else if (msglog.extra_key === "copytrade_sl") {
              const id = msglog.wallet_address;
              if (isNaN(amount) || amount < 0) {
                await bot.sendMessage(msg.chat.id, "❌ Invalid percent. Please enter a non-negative number.", closeReplyMarkup);
                return;
              }
              await CopyTradeService.setStopLoss(id, amount);
              await bot.sendMessage(msg.chat.id, `✅ Stop loss updated to ${amount}%`, closeReplyMarkup);
              return;
            }
          }
        }

      } else {
        if (text === WITHDRAW_TOKEN_AMT_TEXT.replace(/<[^>]*>/g, "")) {
          await withdrawAddressHandler(bot, msg, messageText, reply_message_id);
        } else if (text === COPY_TRADE_WALLET_TEXT.replace(/<[^>]*>/g, "")) {
          const wallet = messageText.trim();
          await copyTradeSetModeHandler(bot, msg, wallet);
        } else if (isValidWalletAddress(messageText)) {
          await contractInfoScreenHandler(bot, msg, messageText);
          return;
        }
      }
      return;
    }

    // // wallet address
    // if (isValidWalletAddress(messageText)) {
    //   await contractInfoScreenHandler(bot, msg, messageText, 'switch_sell');
    //   return;
    // }
    // wallet address
    if (isValidWalletAddress(messageText)) {
      await contractInfoScreenHandler(bot, msg, messageText);
      return;
    }
  } catch (e) {
    console.log("~messageHandler~", e);
    await bot.sendMessage(msg.chat.id, "⚠️ An error occurred while processing your message. Please try again.", { parse_mode: "HTML" });
  }
};

// Process private key import
const processImportPrivateKey = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  privateKey: string
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    // Validate private key format — only accept full 64-byte secret keys.
    // 32-byte base58 strings are indistinguishable from Solana wallet addresses
    // and must NOT be used as seeds, as that would generate a wrong wallet.
    let keypair: Keypair;
    try {
      const secretKey = bs58.decode(privateKey.trim());
      if (secretKey.length === 32) {
        // 32 bytes looks like a wallet address — reject with a clear message
        await bot.sendMessage(
          msg.chat.id,
          "❌ <b>That looks like a wallet address, not a private key.</b>\n\n" +
          "Solana private keys exported from Phantom, Solflare, or most other wallets are <b>64-byte base58 strings</b> (they look like a long random string starting with characters like <code>4wHd...</code>).\n\n" +
          "Please export your <b>Private Key</b> (not your wallet address) from your wallet app and paste it here.",
          { parse_mode: "HTML", ...closeReplyMarkup }
        );
        return;
      } else if (secretKey.length === 64) {
        keypair = Keypair.fromSecretKey(secretKey);
      } else {
        throw new Error(`Invalid key length: ${secretKey.length} bytes`);
      }
    } catch (e: any) {
      await bot.sendMessage(
        msg.chat.id,
        "❌ Invalid private key format. Please ensure it's a valid base58 encoded Solana private key (64 bytes).",
        closeReplyMarkup
      );
      return;
    }

    const wallet_address = keypair.publicKey.toString();
    const private_key = privateKey.trim();

    // Check if this wallet address already exists anywhere in the DB
    const allUsers = await UserService.find({ username });
    const ownedKeyless = allUsers.find(
      (u: any) =>
        u.wallet_address === wallet_address &&
        (!u.private_key || u.private_key.trim() === '')
    );

    if (ownedKeyless) {
      // User owns this wallet but it has no private key — upgrade it in place
      await UserService.updateMany(
        { username, wallet_address },
        { private_key }
      );
      await bot.sendMessage(
        msg.chat.id,
        `✅ <b>Private Key Added!</b>\n\n🔑 Your wallet <code>${wallet_address}</code> is now fully unlocked and can sign transactions.`,
        { parse_mode: 'HTML', ...closeReplyMarkup }
      );
      await walletViewHandler(bot, msg);
      return;
    }

    // Wallet belongs to a different user or has a key already — check for conflict
    const existingWallet = await UserService.findOne({ wallet_address });
    if (existingWallet) {
      await bot.sendMessage(
        msg.chat.id,
        "❌ This wallet address is already linked to another account.",
        closeReplyMarkup
      );
      return;
    }

    // Check wallet limit
    const users = allUsers;
    if (users.length >= MAX_WALLET) {
      await bot.sendMessage(
        msg.chat.id,
        `❌ You have reached the maximum wallet limit (${MAX_WALLET}).`,
        closeReplyMarkup
      );
      return;
    }

    // Create new user entry
    const nonce = users.length;
    const newUser = {
      chat_id: msg.chat.id.toString(),
      first_name: msg.chat.first_name || "",
      last_name: msg.chat.last_name || "",
      username,
      wallet_address,
      private_key,
      nonce,
      retired: true,
      preset_setting: users[0]?.preset_setting || [0.01, 1, 5, 10],
      referrer_code: users[0]?.referrer_code || "",
      referrer_wallet: users[0]?.referrer_wallet || "",
      referral_code: users[0]?.referral_code || "",
      referral_date: users[0]?.referral_date || "",
      schedule: users[0]?.schedule || "60",
      auto_buy: users[0]?.auto_buy || false,
      auto_buy_amount: users[0]?.auto_buy_amount || "0.1",
      auto_sell_amount: users[0]?.auto_sell_amount || "100",
      burn_fee: users[0]?.burn_fee || false,
    };

    await UserService.create(newUser);

    await bot.sendMessage(
      msg.chat.id,
      `✅ <b>Wallet Imported Successfully!</b>\n\n🔑 <b>Private Key:</b> Imported\n🏦 <b>Wallet Address:</b> ${wallet_address}\n\n<i>This wallet is now available in your wallet list.</i>`,
      closeReplyMarkup
    );

    // Refresh wallet view
    await walletViewHandler(bot, msg);
  } catch (e) {
    console.error("Error importing private key:", e);
    await bot.sendMessage(
      msg.chat.id,
      "❌ Failed to import wallet. Please try again.",
      closeReplyMarkup
    );
  }
};

// Process seed phrase import
const processImportSeedPhrase = async (
  bot: TelegramBot,
  msg: TelegramBot.Message,
  seedPhrase: string,
  wordCount: number
) => {
  try {
    const username = msg.chat.username;
    if (!username) return;

    const words = seedPhrase.trim().split(/\s+/);
    if (words.length !== wordCount) {
      await bot.sendMessage(
        msg.chat.id,
        `❌ Invalid seed phrase. Expected ${wordCount} words, got ${words.length}.`,
        closeReplyMarkup
      );
      return;
    }

    // Validate seed phrase
    if (!bip39.validateMnemonic(seedPhrase.trim())) {
      await bot.sendMessage(
        msg.chat.id,
        "❌ Invalid seed phrase. Please check your words and try again.",
        closeReplyMarkup
      );
      return;
    }

    // Generate keypair from seed
    const seed = await bip39.mnemonicToSeed(seedPhrase.trim());
    const keypair = Keypair.fromSeed(seed.slice(0, 32));
    const wallet_address = keypair.publicKey.toString();
    const private_key = bs58.encode(keypair.secretKey);

    // Check wallet limit and look for existing keyless wallet
    const allSeedUsers = await UserService.find({ username });
    const ownedKeyless = allSeedUsers.find(
      (u: any) =>
        u.wallet_address === wallet_address &&
        (!u.private_key || u.private_key.trim() === '')
    );

    if (ownedKeyless) {
      // Upgrade existing keyless wallet with the derived private key
      await UserService.updateMany({ username, wallet_address }, { private_key });
      await bot.sendMessage(
        msg.chat.id,
        `✅ <b>Private Key Added!</b>\n\n🌱 Your wallet <code>${wallet_address}</code> is now fully unlocked and can sign transactions.`,
        { parse_mode: "HTML", ...closeReplyMarkup }
      );
      await walletViewHandler(bot, msg);
      return;
    }

    // Check if wallet belongs to another account
    const existingWallet = await UserService.findOne({ wallet_address });
    if (existingWallet) {
      await bot.sendMessage(
        msg.chat.id,
        "❌ This wallet address is already linked to another account.",
        closeReplyMarkup
      );
      return;
    }

    if (allSeedUsers.length >= MAX_WALLET) {
      await bot.sendMessage(
        msg.chat.id,
        `❌ You have reached the maximum wallet limit (${MAX_WALLET}).`,
        closeReplyMarkup
      );
      return;
    }

    // Create new user entry
    const nonce = allSeedUsers.length;
    const newUser = {
      chat_id: msg.chat.id.toString(),
      first_name: msg.chat.first_name || "",
      last_name: msg.chat.last_name || "",
      username,
      wallet_address,
      private_key,
      nonce,
      retired: true,
      preset_setting: allSeedUsers[0]?.preset_setting || [0.01, 1, 5, 10],
      referrer_code: allSeedUsers[0]?.referrer_code || "",
      referrer_wallet: allSeedUsers[0]?.referrer_wallet || "",
      referral_code: allSeedUsers[0]?.referral_code || "",
      referral_date: allSeedUsers[0]?.referral_date || "",
      schedule: allSeedUsers[0]?.schedule || "60",
      auto_buy: allSeedUsers[0]?.auto_buy || false,
      auto_buy_amount: allSeedUsers[0]?.auto_buy_amount || "0.1",
      auto_sell_amount: allSeedUsers[0]?.auto_sell_amount || "100",
      burn_fee: allSeedUsers[0]?.burn_fee || false,
    };

    await UserService.create(newUser);

    await bot.sendMessage(
      msg.chat.id,
      `✅ <b>Wallet Imported Successfully!</b>\n\n🌱 <b>Seed Phrase:</b> ${wordCount}-word imported\n🏦 <b>Wallet Address:</b> ${wallet_address}\n\n<i>This wallet is now available in your wallet list.</i>`,
      closeReplyMarkup
    );

    // Refresh wallet view
    await walletViewHandler(bot, msg);
  } catch (e) {
    console.error("Error importing seed phrase:", e);
    await bot.sendMessage(
      msg.chat.id,
      "❌ Failed to import wallet. Please try again.",
      closeReplyMarkup
    );
  }
};
