require("dotenv").config();
import startTradeBot from "./src/main";
import connectMongodb from "./src/services/mongodb";

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection at:', promise, 'reason:', reason);
});

// connect mongodb
connectMongodb()
  .then(() => {
    console.log('MongoDB connected');
    // Start the trading bot directly (Redis has been replaced with in-memory cache)
    startTradeBot();
  })
  .catch(error => console.log("MongoDB connect failed", error));

